package app.muttp.schedule

import android.content.Context
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class Notice(
    val id: String,
    val title: String,
    val type: String,
    val text: String,
    val url: String
)

/**
 * Загружает объявления с главной страницы muttp.ru.
 * Новизна определяется по отпечатку заголовка и текста, прочтение хранится на устройстве.
 */
object NotificationsRepo {
    private const val PAGE = "https://muttp.ru/"
    private const val PREFS = "muttp_notices"
    private const val DATA = "notices"
    private const val READ = "read_ids"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): List<Notice> {
        val raw = prefs(c).getString(DATA, null) ?: return emptyList()
        return try {
            val arr = org.json.JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Notice(o.getString("id"), o.getString("title"), o.getString("type"),
                    o.getString("text"), o.getString("url"))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun unreadCount(c: Context): Int {
        val read = prefs(c).getStringSet(READ, emptySet()).orEmpty()
        return load(c).count { it.id !in read }
    }

    fun markRead(c: Context, id: String) {
        val read = prefs(c).getStringSet(READ, emptySet()).orEmpty().toMutableSet()
        read.add(id)
        prefs(c).edit().putStringSet(READ, read).apply()
    }

    fun update(c: Context): String? {
        return try {
            val conn = URL(PAGE).openConnection() as HttpURLConnection
            val html = try {
                conn.connectTimeout = 15000
                conn.readTimeout = 25000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36")
                if (conn.responseCode != 200) error("HTTP " + conn.responseCode)
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally { conn.disconnect() }

            val found = parse(html)
            if (found.isNotEmpty()) {
                val read = prefs(c).getStringSet(READ, emptySet()).orEmpty().toMutableSet()
                // Если объявление уже было сохранено, статус прочтения сохраняется.
                // Новые ID отсутствуют в read и поэтому подсвечиваются.
                val validIds = found.map { it.id }.toSet()
                read.retainAll(validIds)
                prefs(c).edit()
                    .putString(DATA, org.json.JSONArray().apply {
                        found.forEach { n -> put(org.json.JSONObject().apply {
                            put("id", n.id); put("title", n.title); put("type", n.type)
                            put("text", n.text); put("url", n.url)
                        }) }
                    }.toString())
                    .putStringSet(READ, read)
                    .putLong("checked_ms", System.currentTimeMillis())
                    .apply()
            } else if (load(c).isEmpty()) {
                return "На сайте не найдены объявления пассажирам"
            }
            null
        } catch (e: Exception) {
            e.message ?: "Не удалось загрузить объявления"
        }
    }

    private fun parse(html: String): List<Notice> {
        val doc = Jsoup.parse(html, PAGE)
        val candidates = doc.select("article, .post, .news-item, .announcement")
        val result = LinkedHashMap<String, Notice>()
        for (el in candidates) {
            val titleEl = el.selectFirst(".entry-title, .post-title, h1, h2, h3, h4")
            val title = titleEl?.text()?.trim().orEmpty()
            val bodyEl = el.selectFirst(".entry-content, .post-content, .entry-summary, .post-body")
            val body = (bodyEl ?: el).text().trim()
            val markerCount = Regex("(?i)УВАЖАЕМЫЕ\\s+ПАССАЖИРЫ|ВНИМАНИЕ\\s+ПАССАЖИРОВ").findAll(body).count()
            val titleType = classify(title)
            if (titleType == null && markerCount != 1) continue
            val type = titleType ?: classify(body) ?: continue
            if (body.length < 20) continue
            val finalTitle = title.ifBlank { if (type == "УВАЖАЕМЫЕ ПАССАЖИРЫ!") type else "ВНИМАНИЕ ПАССАЖИРОВ!" }
            val link = el.selectFirst("a[href]")?.absUrl("href")?.takeIf { it.startsWith("https://muttp.ru") } ?: PAGE
            val id = sha256((finalTitle + "|" + body).lowercase())
            result[id] = Notice(id, finalTitle, type, body, link)
        }
        // Запасной разбор для страниц, где объявления выведены без отдельных article/post.
        if (result.isEmpty()) {
            val root = doc.selectFirst("div.content") ?: doc.body()
            val text = root.text().replace(Regex("\\s+"), " ").trim()
            val marker = Regex("(?i)(УВАЖАЕМЫЕ ПАССАЖИРЫ!?|ВНИМАНИЕ ПАССАЖИРОВ!?)")
            val matches = marker.findAll(text).toList()
            for (i in matches.indices) {
                val start = matches[i].range.first
                val end = if (i + 1 < matches.size) matches[i + 1].range.first else text.length
                val chunk = text.substring(start, end).trim()
                if (chunk.length < 30) continue
                val type = classify(chunk) ?: continue
                val title = matches[i].value.uppercase()
                val id = sha256((title + "|" + chunk).lowercase())
                result[id] = Notice(id, title, type, chunk, PAGE)
            }
        }
        return result.values.toList()
    }

    private fun classify(text: String): String? {
        val respectful = Regex("(?i)УВАЖАЕМЫЕ\\s+ПАССАЖИРЫ").find(text)
        val attention = Regex("(?i)ВНИМАНИЕ\\s+ПАССАЖИРОВ").find(text)
        return when {
            respectful == null && attention == null -> null
            attention == null -> "УВАЖАЕМЫЕ ПАССАЖИРЫ!"
            respectful == null -> "ВНИМАНИЕ ПАССАЖИРОВ!"
            attention.range.first < respectful.range.first -> "ВНИМАНИЕ ПАССАЖИРОВ!"
            else -> "УВАЖАЕМЫЕ ПАССАЖИРЫ!"
        }
    }

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
