package app.muttp.schedule

/**
 * ПЕРЕВОЗЧИКИ МАРШРУТОК — редактируется вручную.
 *
 * Чтобы сменить перевозчика или телефон, измени запись в groups ниже.
 * Один маршрут должен встречаться только в одной группе.
 * Для каждого маршрута в окне маршрутки автоматически появится карточка с кнопкой звонка.
 */
object MinibusOwners {
    data class Carrier(
        val routes: Set<String>,
        val owner: String,
        val phone: String,
        val dial: String = phone.filter { it.isDigit() || it == '+' }
    )

    val groups = listOf(
        Carrier(setOf("14", "14д", "34", "38", "46", "47"), "ИП Сливинский С.А.", "+7 996 096 44 45"),
        Carrier(setOf("17н", "37н"), "ИП Кондратьев Р.С.", "+7 4182 40-13-13"),
        Carrier(setOf("13", "20", "21", "26", "35", "40", "45"), "ООО «Ветеран-Авто»", "+7 4182 40-13-13"),
        Carrier(setOf("30н", "30Дн"), "ИП Барков П.В.", "+7 920 331 27 34"),
        Carrier(setOf("27н", "56н"), "ООО «Меркурий»", "+7 930 303 60 89"),
        Carrier(setOf("3Кн", "4", "6", "8н", "15н", "16", "31к", "36", "41", "44", "52", "58н"), "ООО «Автоблюз»", "+7 950 703 45 99"),
        Carrier(setOf("9н", "25н", "55н", "42н"), "ООО «Транспорт-Сервис»", "+7 952 537 72 02")
    )

    fun forRoute(number: String): Carrier? =
        groups.firstOrNull { group -> group.routes.any { it.equals(number, ignoreCase = true) } }
}
