package app.muttp.schedule

import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import org.jsoup.select.NodeVisitor

/** Одно время рейса. depot: 0 нет, 1 «(в депо)», 2 «(из депо)». stars: число звёздочек сайта (0, 1, 2...). */
class TramTime(val hour: Int, val minute: Int, val stars: Int, val depot: Int)

/** Один блок страницы: «Маршрут № N «откуда — куда»» и список времён отправления. */
class TramBlock(val from: String, val to: String) {
    val times = mutableListOf<TramTime>()
}

class TramRoute(val number: String) {
    val blocks = mutableListOf<TramBlock>()
    /** Расшифровки звёздочек сайта по числу звёздочек: «* — СМЕ», «** — рейс через …». */
    val starNotes = mutableMapOf<Int, String>()
}

/** Разбор строки-легенды: «* — рейс до Полиграфк-та; ** — рейс через ул. Кирова». */
internal object StarLegend {
    private val re = Regex("""(\*+)\s*[—–-]?\s*([^*]*)""")

    /** Пары (число звёздочек, текст). Текст может быть пустым: тогда он на следующей строке. */
    fun parse(line: String): List<Pair<Int, String>> =
        re.findAll(line).map { it.groupValues[1].length to it.groupValues[2].trim().trimEnd(';', ' ') }.toList()
}

/**
 * Пометки у времён внутри одного блока. Звёздочки сайта сохраняют своё число («*», «**»),
 * депо получает первое свободное число. Для каждого использованного числа даётся сноска.
 */
internal object Marks {
    class Result(val marks: List<String>, val footnotes: List<String>)

    fun forBlock(times: List<TramTime>, legend: Map<Int, String>, fmt: (String) -> String): Result {
        val levels = times.map { it.stars }.filter { it > 0 }.toSortedSet()
        val hasIn = times.any { it.depot == 1 }
        val hasOut = times.any { it.depot == 2 }
        var next = 1
        fun free(): Int {
            while (next in levels) next++
            return next++
        }
        val inSym = if (hasIn) free() else 0
        val outSym = if (hasOut) free() else 0
        val marks = times.map { t ->
            val parts = mutableListOf<String>()
            if (t.stars > 0) parts.add("*".repeat(t.stars))
            if (t.depot == 1) parts.add("*".repeat(inSym))
            if (t.depot == 2) parts.add("*".repeat(outSym))
            parts.joinToString(",")
        }
        val notes = mutableListOf<Pair<Int, String>>()
        for (l in levels) notes.add(l to fmt(legend[l] ?: "Особый рейс"))
        if (hasIn) notes.add(inSym to "Рейс следует в депо")
        if (hasOut) notes.add(outSym to "Рейс следует из депо")
        return Result(marks, notes.sortedBy { it.first }.map { "*".repeat(it.first) + " " + it.second })
    }
}

class TramRaw(val weekday: List<TramRoute>, val weekend: List<TramRoute>)

/**
 * Разбор страницы https://muttp.ru/passazhiram/raspisanie-dvizheniya-tramvaev/
 * Страница сводится к строкам текста, дальше идёт конечный автомат:
 * раздел (будни/выходные) -> заголовок блока -> времена.
 */
object TramParser {
    private val timeRe = Regex("""(\d{1,2})[.:](\d{2})\s*(\*+)?\s*(?:\(\s*(в депо|из депо)\s*\))?""")
    private val headRe = Regex("""№\s*(\d+)\s*[«"]\s*(.*)""")
    private val dashRe = Regex("""\s*[—–]\s*""")
    private val spaces = Regex("""\s+""")

    /** Текст страницы построчно: границы строк там, где блочные теги и <br>. */
    internal fun lines(root: Element): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        fun flush() {
            val t = spaces.replace(sb.toString().replace('\u00A0', ' '), " ").trim()
            if (t.isNotEmpty()) out.add(t)
            sb.setLength(0)
        }
        root.traverse(object : NodeVisitor {
            override fun head(node: Node, depth: Int) {
                if (node is TextNode) sb.append(node.wholeText)
                else if (node is Element && (node.isBlock || node.tagName() == "br")) flush()
            }

            override fun tail(node: Node, depth: Int) {
                if (node is Element && node.isBlock) flush()
            }
        })
        flush()
        return out
    }

    private fun makeBlock(num: String, rawTitle: String, target: MutableList<TramRoute>): Pair<TramRoute, TramBlock> {
        val title = rawTitle.substringBefore('»').trim('"', ' ')
        val parts = title.split(dashRe, limit = 2)
        val block = TramBlock(parts[0].trim(), parts.getOrElse(1) { "" }.trim())
        val route = target.firstOrNull { it.number == num } ?: TramRoute(num).also { target.add(it) }
        route.blocks.add(block)
        return Pair(route, block)
    }

    fun parse(html: String): TramRaw {
        val doc = Jsoup.parse(html)
        val root: Element = doc.selectFirst("div.content div.post") ?: doc.body()
        val weekday = mutableListOf<TramRoute>()
        val weekend = mutableListOf<TramRoute>()
        var target: MutableList<TramRoute>? = null
        var route: TramRoute? = null
        var block: TramBlock? = null
        var pending: Pair<String, StringBuilder>? = null
        var noteWait = 0

        for (line in lines(root)) {
            val low = line.lowercase()
            val p = pending
            if (p != null) {
                // название блока разорвано на строки, ждём »
                p.second.append(' ').append(line)
                if (p.second.contains('»')) {
                    val t = target
                    if (t != null) {
                        val (r, b) = makeBlock(p.first, p.second.toString(), t)
                        route = r
                        block = b
                    }
                    pending = null
                }
                continue
            }
            if (low.startsWith("рабочие")) {
                target = weekday; route = null; block = null; noteWait = 0
                continue
            }
            if (low.startsWith("выходные")) {
                target = weekend; route = null; block = null; noteWait = 0
                continue
            }
            val t = target ?: continue
            val hasTime = timeRe.containsMatchIn(line)

            if (noteWait > 0 && !hasTime) {
                route?.starNotes?.put(noteWait, line.trimStart('—', '–', '-', ' '))
                noteWait = 0
                continue
            }
            val head = if (hasTime) null else headRe.find(line)
            if (head != null) {
                val rest = head.groupValues[2]
                if (rest.contains('»')) {
                    val (r, b) = makeBlock(head.groupValues[1], rest, t)
                    route = r
                    block = b
                } else {
                    pending = Pair(head.groupValues[1], StringBuilder(rest))
                }
                continue
            }
            if (line.startsWith("*") && !hasTime) {
                for ((level, text) in StarLegend.parse(line)) {
                    if (text.isEmpty()) noteWait = level else route?.starNotes?.put(level, text)
                }
                continue
            }
            if (hasTime) {
                val b = block ?: continue
                for (m in timeRe.findAll(line)) {
                    b.times.add(
                        TramTime(
                            m.groupValues[1].toInt(),
                            m.groupValues[2].toInt(),
                            m.groupValues[3].length,
                            when (m.groupValues[4]) {
                                "в депо" -> 1
                                "из депо" -> 2
                                else -> 0
                            }
                        )
                    )
                }
            }
        }
        return TramRaw(weekday, weekend)
    }
}

enum class TramKind { AB, MB, BA, MA }

/** Проверка перед заменой сохранённой страницы трамваев. */
object TramValidator {
    private val EXPECTED = setOf("1", "2", "3")

    fun validate(raw: TramRaw): List<String> {
        val problems = mutableListOf<String>()
        validateDay("будни", raw.weekday, problems)
        validateDay("выходные", raw.weekend, problems)
        return problems
    }

    private fun validateDay(label: String, routes: List<TramRoute>, out: MutableList<String>) {
        val missing = EXPECTED - routes.map { it.number }.toSet()
        if (missing.isNotEmpty()) out.add("$label: нет трамваев ${missing.sorted().joinToString(",")}")
        for (r in routes) {
            for (k in listOf(TramKind.AB, TramKind.MB, TramKind.BA)) {
                if (TramBuilder.block(r, k) == null) out.add("$label: у трамвая ${r.number} нет блока $k")
            }
            for (b in r.blocks) {
                if (b.times.isEmpty()) out.add("$label: трамвай ${r.number}, пустой блок «${b.from}»")
                for (t in b.times) {
                    if (t.hour > 23 || t.minute > 59) out.add("$label: трамвай ${r.number}, странное время ${t.hour}.${t.minute}")
                }
            }
        }
    }
}

/**
 * Сборка для показа. Сайт даёт отправления с конечных и с Медгородка. Время на площади Победы
 * считается: от Медгородка +11 минут (в сторону ул. Багратиона), от ул. Багратиона +16 минут.
 * Порядок остановок: начальная, Медгородок, пл. Победы, ул. Багратиона, пл. Победы, Медгородок.
 */
object TramBuilder {
    private const val MED_TO_POBEDY = 11
    private const val BAGR_TO_POBEDY = 16
    private const val BAGR = "ул. Багратиона"
    private val aNames = mapOf(
        "1" to "Полиграфкомбинат",
        "2" to "П.Алексеева (рынок)",
        "3" to "Рославльское кольцо"
    )

    fun kind(b: TramBlock): TramKind {
        val f = b.from.lowercase()
        val t = b.to.lowercase()
        return when {
            "медгородок" in f -> if ("багратиона" in t) TramKind.MB else TramKind.MA
            "багратиона" in f -> TramKind.BA
            else -> TramKind.AB
        }
    }

    fun block(r: TramRoute, k: TramKind): TramBlock? = r.blocks.firstOrNull { kind(it) == k }

    fun build(raw: TramRaw): Schedule = Schedule(
        raw.weekday.map { route(it) }.sortedBy { it.number },
        raw.weekend.map { route(it) }.sortedBy { it.number }
    )

    /** Трамвай № 4 сейчас не ходит, расписания нет. */
    fun stub(): Route {
        val r = Route("4", "")
        r.lines = listOf("П.Алексеева (рынок)", "Ситники")
        r.info.add("Движение трамвая № 4 временно приостановлено.")
        r.info.add("Рекомендуем воспользоваться автобусом № 50 и маршрутным такси № 27н.")
        return r
    }

    private fun route(tr: TramRoute): Route {
        val aName = aNames[tr.number] ?: block(tr, TramKind.AB)?.from?.ifEmpty { null } ?: "Начальная остановка"
        val r = Route(tr.number, "")
        r.lines = listOf(aName, BAGR)
        // плитка направления «в сторону ул. Багратиона» (без заголовка)
        val toB = Group("")
        add(toB, tr, aName, block(tr, TramKind.AB), 0)
        add(toB, tr, "Медгородок - $BAGR", block(tr, TramKind.MB), 0)
        add(toB, tr, "пл. Победы - $BAGR", block(tr, TramKind.MB), MED_TO_POBEDY)
        // плитка обратного направления
        val toA = Group("")
        add(toA, tr, BAGR, block(tr, TramKind.BA), 0)
        add(toA, tr, "пл. Победы - $aName", block(tr, TramKind.BA), BAGR_TO_POBEDY)
        add(toA, tr, "Медгородок - $aName", block(tr, TramKind.MA), 0)
        if (toB.stops.isNotEmpty()) r.groups.add(toB)
        if (toA.stops.isNotEmpty()) r.groups.add(toA)
        return r
    }

    private fun add(g: Group, tr: TramRoute, name: String, b: TramBlock?, shift: Int) {
        if (b == null || b.times.isEmpty()) return
        val st = Stop(name)
        val res = Marks.forBlock(b.times, tr.starNotes) { Official.note(it) }
        for ((i, t) in b.times.withIndex()) {
            val total = (t.hour * 60 + t.minute + shift) % (24 * 60)
            st.times.add(Dep(total / 60, total % 60, false, res.marks[i]))
        }
        st.footnotes.addAll(res.footnotes)
        g.stops.add(st)
    }
}
