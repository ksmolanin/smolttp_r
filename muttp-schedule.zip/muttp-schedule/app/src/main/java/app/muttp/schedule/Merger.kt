package app.muttp.schedule

/**
 * Объединение маршрутов, которые на сайте разнесены, в один.
 * Рейсы «дополнительного» маршрута получают звёздочку, а под расписанием появляется пометка.
 * Проверка (Validator) работает по сырым данным сайта, объединение только для показа.
 */
object Merger {
    private class Rule(val main: String, val extra: String, val result: String, val note: String)

    private val rules = listOf(
        Rule(main = "24д", extra = "24", result = "24", note = "только до ТЭЦ-2"),
        Rule(main = "53", extra = "53д", result = "53", note = "с заездом в Вишенки"),
    )

    private val nonWord = Regex("""[^\p{L}\p{N}]""")
    private fun norm(s: String) = nonWord.replace(s.lowercase(), "")

    fun apply(s: Schedule): Schedule = Schedule(mergeAll(s.weekday), mergeAll(s.weekend))

    private fun mergeAll(routes: List<Route>): List<Route> {
        var list = routes
        for (rule in rules) {
            val main = list.firstOrNull { it.number == rule.main }
            val extra = list.firstOrNull { it.number == rule.extra }
            if (main == null || extra == null) continue

            val merged = Route(rule.result, main.title)
            for (st in main.stops) {
                val copy = Stop(st.name)
                copy.times.addAll(st.times)
                merged.stops.add(copy)
            }
            for (st in extra.stops) {
                var target = merged.stops.firstOrNull { norm(it.name) == norm(st.name) }
                if (target == null) {
                    target = Stop(st.name)
                    merged.stops.add(target)
                }
                for (d in st.times) target.times.add(Dep(d.hour, d.minute, true))
            }
            for (st in merged.stops) st.times.sortBy { it.hour * 60 + it.minute }
            merged.notes.addAll(main.notes)
            merged.notes.addAll(extra.notes)
            merged.notes.add(rule.note)

            list = list.filter { it !== main && it !== extra } + merged
        }
        return list.sortedWith(Parser.routeOrder)
    }
}
