package app.muttp.schedule

/**
 * РАСЧЁТНЫЕ ПРОМЕЖУТОЧНЫЕ ОСТАНОВКИ АВТОБУСОВ — редактируется здесь, больше нигде не нужно.
 *
 * Время таких остановок не с сайта: оно считается как «время отправления с одного из блоков
 * сайта» + N минут, и показывается отдельной строкой в расписании маршрута.
 *
 * Как устроены индексы блоков. На странице сайта у каждого маршрута одна, две или несколько
 * таблиц отправлений («блоков»), и в приложении они пронумерованы в том порядке, в котором
 * идут на странице: первый блок — 0, второй — 1, третий — 2 и так далее. Чтобы узнать, какой
 * блок каким номером идёт у конкретного маршрута, проще всего открыть сайт muttp.ru и
 * посмотреть, в каком порядке там идут таблицы «Маршрут № …» для него.
 *
 * Чтобы добавить новую расчётную остановку, допиши в список ниже:
 *
 *   Rule(sourceBlock = 0, offsetMinutes = 9, label = "Колхозная пл. - Колодня", afterBlock = 0)
 *
 * где sourceBlock — с какого блока брать время отправления, offsetMinutes — сколько минут
 * прибавить, label — как подписать новую остановку, afterBlock — после какого блока (по номеру
 * на сайте, не считая уже добавленных остановок) показать результат в списке.
 *
 * Необязательные поля:
 *   excludeIfTextContains — рейсы, у которых в расшифровке их звёздочки встречается одно из
 *     этих слов (например «колхоз», «желябов»), в расчёт не берутся — считается, что досюда
 *     они не доезжают.
 *   onlyStarredTrips — взять только рейсы со звёздочкой (например, с заездом куда-то).
 *   dropStarLevel — убрать этот номер звёздочки (1, 2…) у рейсов в новой остановке: звёздочка
 *     была важна для исходного блока, а в расчётном уже не нужна.
 *
 * Если сайт поменяет структуру блоков маршрута (блоков станет меньше, чем указано здесь), эти
 * правки просто не применятся для него — приложение не сломается, но расчётная остановка
 * пропадёт, пока кто-то не поправит номера блоков здесь.
 */
object ArrivalOffsets {
    class Rule(
        val sourceBlock: Int,
        val offsetMinutes: Int,
        val label: String,
        val afterBlock: Int = sourceBlock,
        val excludeIfTextContains: List<String> = emptyList(),
        val onlyStarredTrips: Boolean = false,
        val dropStarLevel: Int? = null
    )

    // ⚠️ При переносе из прежнего варианта кода (additions() в Tweaks.kt) замечено, что для
    // маршрутов «3» и «14» sourceBlock, похоже, указывает не на ту сторону: по описанию должно
    // быть «+9 минут от пл. Победы» и «+10 минут от ул. Кирова», а в коде источник — блок 0
    // (видимо, «Колодня» и «Шейновка» соответственно). Поведение здесь сохранено один в один
    // со старым кодом, чтобы ничего не сломать при переносе — но стоит открыть приложение и
    // проверить обе эти строки: если направление перепутано, достаточно поменять sourceBlock
    // с 0 на 1 (и afterBlock так же, если расчётная остановка должна стоять по другую сторону).
    private val rules: Map<String, List<Rule>> = mapOf(
        "3" to listOf(
            Rule(sourceBlock = 0, offsetMinutes = 9, label = "Колхозная пл. - Колодня")
        ),
        "7" to listOf(
            Rule(sourceBlock = 0, offsetMinutes = 9, label = "Колхозная пл. - Корохоткино"),
            // Пасово — только у рейсов с заездом (они со звёздочкой), в этой строке звёздочка не нужна
            Rule(
                sourceBlock = 1,
                offsetMinutes = 7,
                label = "Пасово - пл. Победы",
                onlyStarredTrips = true,
                dropStarLevel = 1
            )
        ),
        "9" to listOf(
            Rule(sourceBlock = 1, offsetMinutes = 27, label = "пл. Победы (Типография) - Колхозный пер.")
        ),
        "11" to listOf(
            Rule(sourceBlock = 1, offsetMinutes = 14, label = "мкрн. Южный - пл. Победы")
        ),
        "14" to listOf(
            Rule(sourceBlock = 0, offsetMinutes = 10, label = "пл. Победы - Шейновка")
        ),
        "19" to listOf(
            Rule(sourceBlock = 0, offsetMinutes = 9, label = "Колхозная пл. - Спортбаза")
        ),
        "22" to listOf(
            // рейс «до Колхозной площади» на Победы не едет, в расчёт не берётся
            Rule(
                sourceBlock = 0,
                offsetMinutes = 25,
                label = "пл. Победы - 8-й мкрн. Киселевка",
                excludeIfTextContains = listOf("колхоз")
            ),
            // «22з» (через промзону, звёздочка «2») на этой стороне неактуальна
            Rule(
                sourceBlock = 1,
                offsetMinutes = 24,
                label = "пл. Победы - ул. Автозаводская",
                dropStarLevel = 2
            )
        ),
        "31" to listOf(
            Rule(sourceBlock = 0, offsetMinutes = 9, label = "пл. Победы (Типография) - Миловидово")
        ),
        "31к" to listOf(
            Rule(sourceBlock = 0, offsetMinutes = 9, label = "пл. Победы (Типография) - ЖК Загорье")
        ),
        "33" to listOf(
            Rule(sourceBlock = 0, offsetMinutes = 13, label = "пл. Победы (Типография) - Вишенки")
        ),
        "34" to listOf(
            Rule(sourceBlock = 0, offsetMinutes = 20, label = "Колхозная пл. - 7-й мкрн. Киселевка")
        ),
        // 50: блок сайта «пл. Желябова - Вишенки» заменён расчётом; рейсы до Колхозной (Желябова)
        // и до Академии спорта в расчёт соответствующих строк не берутся
        "50" to listOf(
            Rule(
                sourceBlock = 0,
                offsetMinutes = 41,
                label = "к/т Современник - Вишенки",
                excludeIfTextContains = listOf("колхоз", "желябов", "академ")
            ),
            Rule(
                sourceBlock = 0,
                offsetMinutes = 23,
                label = "пл. Желябова - Вишенки",
                excludeIfTextContains = listOf("колхоз", "желябов")
            ),
            Rule(
                sourceBlock = 1,
                offsetMinutes = 39,
                label = "пл. Желябова - Велижская",
                excludeIfTextContains = listOf("колхоз", "желябов")
            )
        ),
        "53" to listOf(
            Rule(sourceBlock = 0, offsetMinutes = 13, label = "пл. Победы (Типография) - Окружная дорога")
        )
    )

    fun rulesFor(routeNumber: String): List<Rule> = rules[routeNumber].orEmpty()
}
