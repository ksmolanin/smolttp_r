package app.muttp.schedule

/**
 * Промежуточные остановки, которые пользователь сам добавляет на главный экран автобусного
 * маршрута (панель «три полоски» → галочка). Время для них не хранится в Route при разборе
 * сайта (как раньше) — оно считается здесь, в момент показа экрана, по данным TransitRegistry
 * и текущему выбору в CustomStops, чтобы включение/выключение остановки работало мгновенно,
 * без повторной загрузки расписания.
 *
 * Работает для маршрутов из таблицы ниже. Это не все автобусы: для 12, 24, 24в, 33, 50, 53, 54
 * на сайте несколько похожих блоков на один маршрут (варианты «с заездом», объединённые блоки),
 * и без проверки на реальном телефоне безопаснее было не трогать их первой версией — доделаем
 * отдельно, когда эта часть подтвердится.
 */
object LiveIntermediates {
    class Anchor(
        val keyword: String,
        /** "forward" или "reverse" — какое направление в transit_registry.json соответствует этому блоку. */
        val dirKey: String,
        /** true: название блока должно совпадать с keyword целиком, а не просто содержать его
         *  (нужно там, где одно слово входит в название сразу двух разных блоков). */
        val exact: Boolean = false,
        val variantOf: String? = null,
        val excludeIfTextContains: List<String> = emptyList(),
        val dropStarLevel: Int? = null
    )

    private val anchors: Map<String, List<Anchor>> = mapOf(
        "3" to listOf(Anchor("колодня", "forward"), Anchor("победы", "reverse")),
        "7" to listOf(
            Anchor("корохоткино", "forward", variantOf = "7 с заездом в Пасово"),
            Anchor("победы", "reverse", variantOf = "7 с заездом в Пасово")
        ),
        "11" to listOf(Anchor("победы", "forward"), Anchor("рябинов", "reverse")),
        "19" to listOf(Anchor("колодня", "forward"), Anchor("победы", "reverse")),
        "22" to listOf(
            Anchor("автозаводск", "forward", excludeIfTextContains = listOf("колхоз")),
            Anchor("киселев", "reverse", dropStarLevel = 2)
        ),
        "31" to listOf(Anchor("колхоз", "forward"), Anchor("миловид", "reverse")),
        "31к" to listOf(Anchor("колхоз", "forward"), Anchor("загорь", "reverse")),
        "34" to listOf(Anchor("королев", "forward"), Anchor("37", "reverse"))
    )

    fun hasAnchors(routeNumber: String): Boolean = anchors.containsKey(routeNumber)

    /** Кандидаты для направления маршрута без привязки к конкретным Stop/Route — для панели остановок. */
    fun candidatesForDirection(routeNumber: String, forward: Boolean): List<TransitRegistry.Candidate> {
        val a = anchors[routeNumber]?.firstOrNull { (it.dirKey == "forward") == forward } ?: return emptyList()
        return TransitRegistry.candidates(routeNumber, a.dirKey, a.variantOf)
    }

    private val nonWord = Regex("""[^\p{L}\p{N}]""")
    private fun norm(s: String) = nonWord.replace(s.lowercase().replace('ё', 'е'), "")

    private fun matchStop(stops: List<Stop>, anchor: Anchor): Stop? {
        val kw = norm(anchor.keyword)
        return if (anchor.exact) stops.firstOrNull { norm(it.name) == kw }
        else stops.firstOrNull { norm(it.name).contains(kw) }
    }

    /** Один «якорный» блок маршрута (обычно по одному на направление) с доступными кандидатами. */
    class Block(val anchorStop: Stop, val forward: Boolean, val candidates: List<TransitRegistry.Candidate>)

    /** Якорные блоки этого маршрута, которые реально нашлись среди его остановок на сайте. */
    fun blocksFor(r: Route): List<Block> {
        val list = anchors[r.number] ?: return emptyList()
        return list.mapNotNull { a ->
            val stop = matchStop(r.stops, a) ?: return@mapNotNull null
            if (stop.times.isEmpty()) return@mapNotNull null
            val cands = TransitRegistry.candidates(r.number, a.dirKey, a.variantOf)
            if (cands.isEmpty()) return@mapNotNull null
            Block(stop, a.dirKey == "forward", cands).also { /* excludeIfTextContains/dropStarLevel читаются ниже через anchor */ }
        }
    }

    private fun anchorFor(r: Route, forward: Boolean): Anchor? =
        anchors[r.number]?.firstOrNull { (it.dirKey == "forward") == forward }

    /** Время прибытия расчётной остановки: время блока-источника + candidate.minutes. */
    fun computeStop(r: Route, block: Block, candidate: TransitRegistry.Candidate): Stop {
        val anchor = anchorFor(r, block.forward)
        val st = Stop(candidate.name)
        for (d in block.anchorStop.times) {
            if (candidate.starredOnly && d.stars == 0) continue
            if (!candidate.starredOnly && d.stars > 0 && anchor != null && anchor.excludeIfTextContains.isNotEmpty()) {
                val text = r.legend[d.stars].orEmpty().joinToString(" ").lowercase()
                if (anchor.excludeIfTextContains.any { it in text }) continue
            }
            val total = (d.hour * 60 + d.minute + candidate.minutes) % (24 * 60)
            val stars = if (anchor != null && d.stars == anchor.dropStarLevel) 0 else d.stars
            st.times.add(Dep(total / 60, total % 60, false, "", stars, d.annot))
        }
        return st
    }
}
