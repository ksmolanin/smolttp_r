package app.muttp.schedule

/**
 * Маршрутки. Данных на сайте нет, расписание задано вручную.
 * Маршрут либо с интервалом (текст), либо со списками времён по остановкам.
 */
object Minibus {
    private const val FOOTER = "После 21:00 движение не гарантировано"
    private const val FORMING = "График может не соблюдаться"

    private class Body(
        val info: List<String> = emptyList(),
        val stops: List<Pair<String, String>> = emptyList(),
        val remarks: List<String> = emptyList()
    )

    private class Def(val number: String, val lines: List<String>, val weekday: Body, val weekend: Body = weekday)

    private val timeRe = Regex("""(\d{1,2})[-:.](\d{2})""")

    private fun times(s: String): List<Dep> =
        timeRe.findAll(s).map { Dep(it.groupValues[1].toInt(), it.groupValues[2].toInt(), false) }.toList()

    private const val DEFAULT_HOURS = "с 6:00 до 22:30"

    /** Плавающее расписание: интервал и график вместо списка рейсов. */
    private fun floating(
        interval: String,
        extra: List<String> = emptyList(),
        hours: String = DEFAULT_HOURS,
        remarks: List<String> = emptyList()
    ) = Body(
        info = listOf("Интервал: $interval", "График: $hours") + extra,
        remarks = remarks
    )

    /** Обычный режим: интервал 15 мин. */
    private val regular = floating("15 мин")

    // Корохоткино и ул. Пригородная (маршрут 21), такие же времена у 40
    private const val KOR_WD = "7:10 8:20 9:30 10:40 11:50 13:00 14:10 15:20 16:30 17:40 18:50 20:00 21:10"
    private const val PRI_WD = "8:10 9:20 10:30 11:40 13:00 14:10 15:20 16:30 17:40 18:50 20:00 21:10"
    private const val KOR_WE = "8:10 9:20 10:30 11:40 12:50 14:00 15:10 16:20 17:30 18:40 19:50 21:00"
    private const val PRI_WE = "7:00 8:10 9:20 10:30 11:40 12:50 14:00 15:10 16:20 17:30 18:40 19:50 21:00"

    private val defs = listOf(
        Def("3Кн", listOf("Колодня", "Колхозная площадь"), regular),
        Def("4", listOf("ул. Мало-Краснофлотская", "Шейновка"), floating("30 мин")),
        Def("6", listOf("Аркада", "ул. Автозаводская"), floating("40 мин", remarks = listOf(FORMING))),
        Def("13", listOf("Королёвка 15а", "ул. Чаплина", "Королёвка 15а"), floating("25 мин")),
        Def(
            "14д", listOf("ул. Шейна 115", "ул. Ленина", "ул. Шейна 115"),
            floating("30 мин", remarks = listOf(FORMING))
        ),
        Def("16", listOf("ул. В.Гризодубовой", "ул. 25 сентября", "ул. В.Гризодубовой"), regular),
        Def("17н", listOf("СТО", "пл. Победы", "СТО"), regular),
        Def("20", listOf("Аркада", "8-й мкрн. Киселевка"), floating("10 мин")),
        Def(
            "21", listOf("ул. Пригородная", "Корохоткино"),
            weekday = Body(
                stops = listOf("Корохоткино" to KOR_WD, "ул. Пригородная" to PRI_WD),
                remarks = listOf(FORMING)
            ),
            weekend = Body(
                stops = listOf("Корохоткино" to KOR_WE, "ул. Пригородная" to PRI_WE),
                remarks = listOf(FORMING)
            )
        ),
        Def("26", listOf("пос. Миловидово", "пл. Желябова"), regular),
        Def("27н", listOf("Ситники", "физдиспансер", "Ситники"), floating("5 мин")),
        Def("30Дн", listOf("пл. Желябова", "Ракитная ул."), floating("30 мин")),
        Def(
            "35", listOf("Вишенки", "6-й мкрн. Киселевка"),
            weekday = Body(info = listOf("Интервал: 30 мин (с 7:00 до 21:00)"), remarks = listOf(FORMING)),
            weekend = Body(info = listOf("Интервал: 1 ч (с 7:00 до 20:00)"), remarks = listOf(FORMING))
        ),
        Def(
            "36", listOf("Гвоздово", "пл. Желябова"),
            weekday = Body(
                stops = listOf(
                    "пл. Желябова" to "6-00 7-10 7-30 8-30 9-10 10-00 10-30 11-30 12-30 14-05 14-50 16-10 16-40 17-40 18-10 19-15",
                    "Гвоздово" to "6-30 7-40 8-10 9-15 9-50 10-40 11-10 12-10 13-15 15-00 15-35 16-55 17-25 18-35 18-55 20-00"
                ),
                remarks = listOf(FORMING)
            ),
            weekend = Body(
                stops = listOf(
                    "пл. Желябова" to "6-00 7-10 7-40 8-40 9-15 10-20 11-15 12-00 13-20 14-20 15-00 15-50 16-40 17-25 18-10",
                    "Гвоздово" to "6-30 7-40 8-20 9-20 9-55 11-00 11-55 12-40 14-05 15-00 15-55 16-30 17-20 18-10 18-50"
                ),
                remarks = listOf(FORMING)
            )
        ),
        Def("37н", listOf("Колхозный пер.", "СТО"), regular),
        Def("38", listOf("Кловская ул.", "Королёвка 15а"), regular),
        Def(
            "40", listOf("Ж/д вокзал", "мкрн. Соловьиная Роща"),
            weekday = Body(
                stops = listOf("Ж/д вокзал" to KOR_WD, "мкрн. Соловьиная Роща" to PRI_WD),
                remarks = listOf(FORMING)
            ),
            weekend = Body(
                stops = listOf("Ж/д вокзал" to KOR_WE, "мкрн. Соловьиная Роща" to PRI_WE),
                remarks = listOf(FORMING)
            )
        ),
        Def("41", listOf("Ж/д вокзал", "Рябиновая поляна"), floating("10 мин")),
        Def(
            "42н", listOf("ул. Авиаторов 5", "мкрн. Соловьиная Роща"),
            Body(
                stops = listOf("мкрн. Соловьиная Роща" to "7:00", "ул. Авиаторов 5" to "8:30"),
                remarks = listOf("Доподлинно не известно")
            )
        ),
        Def("44", listOf("Шарм", "8-й мкрн. Киселевка"), floating("5 мин")),
        Def("45", listOf("Кловская ул.", "ул. П.Алексеева (рынок)"), floating("10 мин")),
        Def(
            "46", listOf("ул. Островского", "Киевский пер."),
            floating("10 мин", extra = listOf("С 20:00 интервал: 30 мин"))
        ),
        Def("47", listOf("Аркада", "пл. Желябова"), regular),
        Def(
            "52", listOf("пл. Победы", "СОК Смена"),
            Body(
                stops = listOf(
                    "СОК Смена" to "8:20 9:55 11:30 13:05 14:40 16:15 17:50 19:25 21:10",
                    "пл. Победы" to "7:35 9:10 10:45 12:20 13:55 15:30 17:05 18:40 20:15"
                ),
                remarks = listOf(FORMING)
            )
        ),
        Def("55н", listOf("Кловская ул.", "ул. Ново-Московская (ТРЦ Галактика)"), regular),
        Def("56н", listOf("ул. Автозаводская", "8-й мкрн. Киселевка"), floating("5 мин")),
        Def("58н", listOf("Миловидово", "8-й мкрн. Киселевка"), regular),
        // дублёры: направления те же, что у одноимённых автобусов
        Def("8н", listOf("пл. Победы", "М.Краснофлотская"), floating("20 мин", hours = "с 7:00 до 22:00")),
        Def(
            "9н", listOf("Садки", "Колхозный переулок"),
            floating(
                "10 мин",
                hours = "с 6:30 до 22:00",
                remarks = listOf(
                    "7:00-9:00 и 17:30-19:30 заезд на ул. Полевую в обе стороны",
                    "Из центра заезд по требованию"
                )
            )
        ),
        Def("15н", listOf("пос. Анастасино", "пл. Желябова"), floating("1 ч")),
        Def("25н", listOf("Ж/д вокзал", "8-й мкрн. Киселевка"), floating("10 мин")),
        Def("30н", listOf("мкрн. Гнёздово (ул. Щорса)", "пл. Желябова"), floating("15 мин")),
        Def("34", listOf("мкрн. Королевка", "7-й мкрн. (Киселевка)"), floating("15 мин")),
        Def(
            "31к", listOf("пл. Желябова", "ЖК Загорье"),
            floating(
                "≈1ч",
                hours = "с 16:30 до 20:00",
                remarks = listOf(FORMING, "Воспользуйтесь муниципальным автобусом 31к")
            )
        ),
    )

    private fun build(d: Def, b: Body): Route {
        val r = Route(d.number, "")
        r.lines = d.lines
        r.info.addAll(b.info)
        for ((name, t) in b.stops) {
            val st = Stop(name)
            st.times.addAll(times(t))
            r.stops.add(st)
        }
        r.remarks.addAll(b.remarks)
        r.remarks.add(FOOTER)
        return r
    }

    fun build(): Schedule = Schedule(
        defs.map { build(it, it.weekday) }.sortedWith(Parser.routeOrder),
        defs.map { build(it, it.weekend) }.sortedWith(Parser.routeOrder)
    )
}
