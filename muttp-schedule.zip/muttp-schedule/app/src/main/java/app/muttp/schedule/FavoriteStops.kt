package app.muttp.schedule

import android.content.Context
import org.json.JSONObject
import java.util.Locale

/** Пользовательские настройки избранных остановок. Исходный реестр и расписание не изменяются. */
object FavoriteStops {
    private const val PREFS = "favorite_stops_v1"

    data class DirectionData(val names: List<String>, val codes: List<String>, val minutes: List<Int?>)
    data class RouteData(val forward: DirectionData, val reverse: DirectionData)

    private val registryCache = mutableMapOf<String, RouteData>()

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun prefKey(section: String, route: String, variant: Int, direction: Int, identity: String) =
        "$section|$route|$variant|$direction|$identity"

    private fun stopIdentity(context: Context, section: String, route: String, variant: Int, direction: Int, name: String): String {
        val path = routeData(context, section, route, variant)?.let { if (direction == 0) it.forward else it.reverse }
        val index = path?.names?.indexOfFirst { normalize(it) == normalize(name) } ?: -1
        return path?.codes?.getOrNull(index) ?: normalize(name)
    }

    fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace("ё", "е").replace(Regex("[^\\p{L}\\p{N}]"), "")

    /** По умолчанию автобусам включаем только терминалы; трамваям и троллейбусам — все остановки сайта. */
    fun isEnabled(
        context: Context, section: String, route: String, variant: Int, direction: Int,
        index: Int, stops: List<String>, siteStops: Set<String>
    ): Boolean {
        val key = prefKey(section, route, variant, direction, stopIdentity(context, section, route, variant, direction, stops[index]))
        if (prefs(context).contains(key)) return prefs(context).getBoolean(key, false)
        return normalize(stops[index]) in siteStops.map(::normalize).toSet()
    }

    fun selected(
        context: Context, section: String, route: String, variant: Int, direction: Int,
        stops: List<String>, siteStops: Set<String>
    ): List<String> = stops.filterIndexed { i, _ -> isEnabled(context, section, route, variant, direction, i, stops, siteStops) }

    /** Возвращает null, если действие нарушает лимит или оставляет направление пустым. */
    fun toggle(
        context: Context, section: String, route: String, variant: Int, direction: Int,
        stops: List<String>, siteStops: Set<String>, index: Int
    ): String? {
        if (index !in stops.indices) return "Остановка не найдена"
        val selected = selected(context, section, route, variant, direction, stops, siteStops)
        val name = stops[index]
        val enabled = name in selected
        if (enabled && selected.size == 1) return "Нельзя отключить последнюю отображаемую остановку"
        if (!enabled && section == "bus" && selected.size >= 3) {
            return "Для автобуса можно отображать не больше трёх остановок на направление"
        }
        if (!enabled && section in setOf("tram", "trolley")) {
            val siteSelectedCount = selected.count { isSiteStop(siteStops, it) }
            val userSelectedCount = selected.size - siteSelectedCount
            val limit = when (siteSelectedCount) { 0 -> 3; 1 -> 2; 2 -> 1; else -> 1 }
            val siteStop = isSiteStop(siteStops, name)
            if (!siteStop && userSelectedCount >= limit) return "Достигнут лимит пользовательских остановок ($limit)"
        }
        prefs(context).edit().putBoolean(prefKey(section, route, variant, direction, stopIdentity(context, section, route, variant, direction, name)), !enabled).apply()
        return null
    }

    /** Остановки, для которых сайт реально публикует отдельные времена отправления. */
    private fun isSiteStop(siteStops: Set<String>, name: String): Boolean =
        siteStops.any { normalize(it) == normalize(name) }

    fun routeData(context: Context, section: String, route: String, variant: Int = 0): RouteData? {
        val key = when (section) {
            "tram" -> "трамвай $route"
            "trolley" -> "троллейбус $route"
            else -> if (route == "7" && variant == 1) "7 с заездом в Пасово" else route
        }
        registryCache[key]?.let { return it }
        return try {
            val root = context.assets.open("transit_stops.json").bufferedReader().use { JSONObject(it.readText()) }
            val raw = root.getJSONObject("routes").optJSONArray(key) ?: return null
            fun direction(namesIndex: Int, timesIndex: Int): DirectionData {
                val namesJson = raw.getJSONArray(namesIndex)
                val timesJson = raw.getJSONArray(timesIndex)
                val codes = (0 until namesJson.length()).map { namesJson.getString(it) }
                val names = codes.map { code -> root.getJSONArray("stops").let { rows ->
                    (0 until rows.length()).firstNotNullOfOrNull { j ->
                        val row = rows.getJSONArray(j)
                        if (row.getString(0) == code) row.getString(1) else null
                    } ?: code
                } }
                val minutes = (0 until timesJson.length()).map { i -> if (timesJson.isNull(i)) null else timesJson.getInt(i) }
                return DirectionData(names, codes, minutes)
            }
            val parsed = RouteData(direction(0, 1), direction(2, 3))
            registryCache[key] = parsed
            parsed
        } catch (_: Exception) { null }
    }

    /** Рассчитывает время от отправления с начала направления до выбранной остановки. */
    fun arrivalStops(
        context: Context, section: String, route: String, direction: Int,
        selected: List<String>, source: Stop?, siteSources: List<Stop> = emptyList(), variant: Int = 0
    ): List<Stop> {
        val data = routeData(context, section, route, variant) ?: return emptyList()
        val path = if (direction == 0) data.forward else data.reverse
        val base = source ?: return emptyList()
        return selected.mapNotNull { wanted ->
            val idx = path.names.indexOfFirst { normalize(it) == normalize(wanted) }
            if (idx < 0) return@mapNotNull null
            val direct = siteSources.firstOrNull { candidate ->
                val candidateName = normalize(candidate.name.substringBefore(" - "))
                candidateName == normalize(wanted) || candidateName.contains(normalize(wanted)) || normalize(wanted).contains(candidateName)
            }
            var offset = 0
            var valid = true
            if (direct == null) {
                for (i in 1..idx) {
                    val m = path.minutes.getOrNull(i)
                    if (m == null) { valid = false; break }
                    offset += m
                }
            }
            if (!valid) return@mapNotNull null
            val result = Stop(wanted)
            for (dep in (direct ?: base).times) {
                val total = dep.hour * 60 + dep.minute + offset
                result.times.add(Dep((total / 60) % 24, total % 60, dep.starred, dep.mark, dep.stars, dep.annot))
            }
            result
        }
    }
}
