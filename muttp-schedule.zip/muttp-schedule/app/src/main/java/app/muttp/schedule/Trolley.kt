package app.muttp.schedule

import org.jsoup.Jsoup
import org.jsoup.nodes.Element

/**
 * Разбор страницы https://muttp.ru/passazhiram/raspisanie-dvizheniya-trollejbusov/
 * Формат тот же, что у трамваев: блоки «Маршрут № N «откуда — куда»» со списком времён.
 * Времена бывают как «6.18», так и «6,18», с пометками «(из депо)», «(в депо)» и «*».
 * Результат хранится в тех же классах TramRaw/TramRoute/TramBlock.
 */
object TrolleyParser {
    private val timeRe = Regex("""(\d{1,2})[.,:](\d{2})\s*(\*)?\s*(?:\(\s*(в\s*депо|из\s*депо)\s*\))?""")
    private val headRe = Regex("""№\s*([\d,\s]+?)\s*[«"]\s*(.*)""")
    private val dashRe = Regex("""\s*[—–]\s*""")
    private val blank = Regex("""\s""")

    private fun makeBlock(num: String, rawTitle: String, target: MutableList<TramRoute>): Pair<TramRoute, TramBlock> {
        val title = rawTitle.substringBefore('»').trim('"', ' ')
        val parts = title.split(dashRe, limit = 2)
        val block = TramBlock(parts[0].trim(), parts.getOrElse(1) { "" }.trim())
        val number = blank.replace(num, "")
        val route = target.firstOrNull { it.number == number } ?: TramRoute(number).also { target.add(it) }
        route.blocks.add(block)
        return Pair(route, block)
    }

    fun parse(html: String): TramRaw {
        val doc = Jsoup.parse(html)
        val root: Element = doc.selectFirst("div.content div.post") ?: doc.body()
        val weekday = mutableListOf<TramRoute>()
        val weekend = mutableListOf<TramRoute>()
        var target: MutableList<TramRoute>? = null
        var route: TramRoute? = null
        var block: TramBlock? = null
        var pending: Pair<String, StringBuilder>? = null
        var noteWait = false

        for (line in TramParser.lines(root)) {
            val low = line.lowercase()
            val p = pending
            if (p != null) {
                p.second.append(' ').append(line)
                if (p.second.contains('»')) {
                    val tg = target
                    if (tg != null) {
                        val (r, b) = makeBlock(p.first, p.second.toString(), tg)
                        route = r
                        block = b
                    }
                    pending = null
                }
                continue
            }
            if (low.startsWith("рабочие")) {
                target = weekday; route = null; block = null; noteWait = false
                continue
            }
            if (low.startsWith("выходные")) {
                target = weekend; route = null; block = null; noteWait = false
                continue
            }
            val t = target ?: continue
            val hasTime = timeRe.containsMatchIn(line)

            if (noteWait && !hasTime) {
                route?.starNote = line
                noteWait = false
                continue
            }
            val head = if (hasTime) null else headRe.find(line)
            if (head != null) {
                val rest = head.groupValues[2]
                if (rest.contains('»')) {
                    val (r, b) = makeBlock(head.groupValues[1], rest, t)
                    route = r
                    block = b
                } else {
                    pending = Pair(head.groupValues[1], StringBuilder(rest))
                }
                continue
            }
            if (line.startsWith("*") && !hasTime) {
                val text = line.trimStart('*', '—', '–', '-', ' ')
                if (text.isEmpty()) noteWait = true else route?.starNote = text
                continue
            }
            if (hasTime) {
                val b = block ?: continue
                for (m in timeRe.findAll(line)) {
                    val depotText = m.groupValues[4]
                    b.times.add(
                        TramTime(
                            m.groupValues[1].toInt(),
                            m.groupValues[2].toInt(),
                            m.groupValues[3].isNotEmpty(),
                            when {
                                depotText.startsWith("в") -> 1
                                depotText.startsWith("из") -> 2
                                else -> 0
                            }
                        )
                    )
                }
            }
        }
        return TramRaw(weekday, weekend)
    }
}

/** Проверка перед заменой сохранённой страницы троллейбусов. */
object TrolleyValidator {
    private val EXPECTED = setOf("1", "2", "3", "4", "2,3")
    private val MIN_BLOCKS = mapOf("1" to 6, "2" to 8, "3" to 8, "4" to 2, "2,3" to 2)

    fun validate(raw: TramRaw): List<String> {
        val problems = mutableListOf<String>()
        validateDay("будни", raw.weekday, problems)
        validateDay("выходные", raw.weekend, problems)
        return problems
    }

    private fun validateDay(label: String, routes: List<TramRoute>, out: MutableList<String>) {
        val missing = EXPECTED - routes.map { it.number }.toSet()
        if (missing.isNotEmpty()) out.add("$label: нет троллейбусов ${missing.sorted().joinToString(",")}")
        for (r in routes) {
            val min = MIN_BLOCKS[r.number] ?: 1
            if (r.blocks.size < min) out.add("$label: у троллейбуса ${r.number} блоков ${r.blocks.size} из $min")
            for (b in r.blocks) {
                if (b.times.isEmpty()) out.add("$label: троллейбус ${r.number}, пустой блок «${b.from}»")
                for (t in b.times) {
                    if (t.hour > 23 || t.minute > 59) out.add("$label: троллейбус ${r.number}, странное время ${t.hour}.${t.minute}")
                }
            }
        }
    }
}

/**
 * Сборка для показа: расписания делятся на плитки по направлению (по конечной «куда»),
 * внутри плитки списки по остановкам отправления. Внизу отдельная плитка «2, 3 в депо».
 */
object TrolleyBuilder {
    private val lines = mapOf(
        "1" to listOf("Полиграфкомбинат", "Шарм"),
        "2" to listOf("37-я школа", "Аркада"),
        "3" to listOf("37-я школа", "Аркада"),
        "4" to listOf("Ламповый з-д", "ул. Кловская"),
        "2,3" to listOf("в депо")
    )
    private val order = listOf("1", "2", "3", "4", "2,3")

    /** Конечные остановки: у них подпись без «куда», у остальных «откуда - куда». */
    private val terminals = mapOf(
        "1" to listOf("Полиграфкомбинат", "Шарм"),
        "2" to listOf("37-я школа", "Аркада"),
        "3" to listOf("37-я школа", "Аркада"),
        "4" to listOf("Ламповый з-д", "ул. Кловская"),
        "2,3" to listOf("37-я школа", "Полиграфкомбинат")
    )
    private val nonWord = Regex("""[^\p{L}\p{N}]""")
    private fun norm(s: String) = nonWord.replace(s.lowercase(), "")

    private val abbr = Regex("""Полиграфк-т(а?)""")
    private val paren = Regex("""(\S)\(""")

    /** Полные названия вместо сокращений сайта и пробел перед скобкой. */
    private fun clean(s: String): String =
        paren.replace(abbr.replace(s.trim()) { "Полиграфкомбинат" + it.groupValues[1] }, "\$1 (")

    fun build(raw: TramRaw): Schedule = Schedule(day(raw.weekday), day(raw.weekend))

    private fun day(routes: List<TramRoute>): List<Route> =
        routes.sortedBy { r -> order.indexOf(r.number).let { if (it < 0) 99 else it } }.map { route(it) }

    private fun route(tr: TramRoute): Route {
        val r = Route(tr.number, "")
        r.lines = lines[tr.number]
            ?: listOf(clean(tr.blocks.firstOrNull()?.from ?: ""), clean(tr.blocks.firstOrNull()?.to ?: ""))
                .filter { it.isNotEmpty() }
        val byTo = LinkedHashMap<String, MutableList<TramBlock>>()
        for (b in tr.blocks) byTo.getOrPut(clean(b.to)) { mutableListOf() }.add(b)
        for ((to, blocks) in byTo) {
            val g = Group(to)
            for (b in blocks) stop(tr, b, to)?.let { g.stops.add(it) }
            r.stops.addAll(g.stops)
        }
        return r
    }

    private fun stop(tr: TramRoute, b: TramBlock, to: String): Stop? {
        if (b.times.isEmpty()) return null
        val from = clean(b.from)
        val isTerminal = terminals[tr.number]?.any { norm(it) == norm(from) } ?: false
        val st = Stop(if (isTerminal) from else "$from - $to")
        // «*» у времён с пометкой депо; если в блоке есть и звёздочка сайта, она показывается как «†»
        val hasDepot = b.times.any { it.depot != 0 }
        val starSym = if (hasDepot) "†" else "*"
        for (t in b.times.sortedBy { it.hour * 60 + it.minute }) {
            val mark = (if (t.depot != 0) "*" else "") + (if (t.star) starSym else "")
            st.times.add(Dep(t.hour, t.minute, false, mark))
        }
        if (b.times.any { it.depot == 1 }) st.footnotes.add("* Рейс следует в депо")
        if (b.times.any { it.depot == 2 }) st.footnotes.add("* Рейс следует из депо")
        if (b.times.any { it.star }) {
            st.footnotes.add("$starSym " + Official.note(clean(tr.starNote.ifEmpty { "Особый рейс" })))
        }
        return st
    }
}
