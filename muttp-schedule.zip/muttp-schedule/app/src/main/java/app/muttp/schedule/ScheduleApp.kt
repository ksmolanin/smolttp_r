package app.muttp.schedule

import android.app.Application

class ScheduleApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Scheduler.ensureScheduled(this)
    }
}
