package app.muttp.schedule

import android.app.Application

class ScheduleApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Scheduler.ensureScheduled(this)
        // данные о времени между остановками (для кастомных промежуточных остановок) — читаются один раз
        TransitRegistry.ensureLoaded(this)
    }
}
