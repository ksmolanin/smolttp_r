package app.muttp.schedule

import android.content.Context

/**
 * Закреплённые маршруты (автобусы и маршрутки). Хранится список номеров по разделам,
 * самый недавно закреплённый стоит первым. Ограничений на количество нет.
 */
object Favorites {
    private fun prefs(c: Context) = c.getSharedPreferences("favorites", Context.MODE_PRIVATE)

    fun load(c: Context, section: String): List<String> =
        prefs(c).getString(section, "").orEmpty().split("\n").filter { it.isNotEmpty() }

    fun save(c: Context, section: String, list: List<String>) {
        prefs(c).edit().putString(section, list.joinToString("\n")).apply()
    }
}

/** Закрепить или открепить: закреплённый уходит в начало списка, открепленный пропадает из него. */
fun togglePin(list: List<String>, number: String): List<String> =
    if (number in list) list - number else listOf(number) + list

/** Закреплённые маршруты сверху (последний закреплённый первым), остальные в прежнем порядке. */
fun List<Route>.pinnedFirst(pins: List<String>): List<Route> {
    if (pins.isEmpty()) return this
    val byNumber = associateBy { it.number }
    val top = pins.mapNotNull { byNumber[it] }
    return top + filter { it.number !in pins }
}
