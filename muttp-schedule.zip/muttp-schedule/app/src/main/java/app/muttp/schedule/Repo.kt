package app.muttp.schedule

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Скачивание, проверка и хранение. В файлах лежит сырой HTML последней удачной загрузки.
 * Автобусы и трамваи обновляются независимо: сбой одной страницы не мешает другой.
 */
object Repo {
    private const val BUS_URL = "https://muttp.ru/raspisanie-dvizheniya-avtobusov/"
    private const val TRAM_URL = "https://muttp.ru/passazhiram/raspisanie-dvizheniya-tramvaev/"
    private const val BUS_FILE = "schedule.html"
    private const val TRAM_FILE = "tram.html"
    private const val STALE_MS = 20L * 3600 * 1000
    const val ERR_NET = "Ошибка интернета"

    private fun prefs(c: Context) = c.getSharedPreferences("schedule", Context.MODE_PRIVATE)

    fun updatedMs(c: Context): Long = prefs(c).getLong("updated_ms", 0L)
    fun tramUpdatedMs(c: Context): Long = prefs(c).getLong("tram_updated_ms", 0L)
    fun lastError(c: Context): String? = prefs(c).getString("last_error", null)
    fun tramLastError(c: Context): String? = prefs(c).getString("tram_last_error", null)

    fun isStale(c: Context): Boolean {
        val now = System.currentTimeMillis()
        return now - updatedMs(c) > STALE_MS || now - tramUpdatedMs(c) > STALE_MS
    }

    fun load(c: Context): Schedule? {
        val f = File(c.filesDir, BUS_FILE)
        if (!f.exists()) return null
        return try {
            Tweaks.apply(Merger.apply(Parser.parse(f.readText())))
        } catch (e: Exception) {
            null
        }
    }

    fun loadTram(c: Context): Schedule? {
        val f = File(c.filesDir, TRAM_FILE)
        if (!f.exists()) return null
        return try {
            TramBuilder.build(TramParser.parse(f.readText()))
        } catch (e: Exception) {
            null
        }
    }

    /** Возвращает null при успехе или текст первой ошибки. Старые данные при ошибке не трогаются. */
    fun update(c: Context): String? {
        val busError = updateOne(c, BUS_URL, BUS_FILE, "updated_ms", "last_error") { html ->
            Validator.validate(Parser.parse(html))
        }
        val tramError = updateOne(c, TRAM_URL, TRAM_FILE, "tram_updated_ms", "tram_last_error") { html ->
            TramValidator.validate(TramParser.parse(html))
        }
        return busError ?: tramError
    }

    private fun updateOne(
        c: Context,
        url: String,
        file: String,
        timeKey: String,
        errorKey: String,
        check: (String) -> List<String>
    ): String? {
        try {
            val html = download(url)
            val problems = check(html)
            if (problems.isNotEmpty()) {
                return fail(c, errorKey, "сайт изменился, парсер не сработал (" + problems.take(3).joinToString("; ") + ")")
            }
            val cur = File(c.filesDir, file)
            val tmp = File(c.filesDir, "$file.tmp")
            tmp.writeText(html)
            tmp.copyTo(cur, overwrite = true)
            tmp.delete()
            prefs(c).edit()
                .putLong(timeKey, System.currentTimeMillis())
                .remove(errorKey)
                .apply()
            return null
        } catch (e: IOException) {
            return fail(c, errorKey, ERR_NET)
        } catch (e: Exception) {
            return fail(c, errorKey, e.message ?: e.javaClass.simpleName)
        }
    }

    private fun fail(c: Context, errorKey: String, msg: String): String {
        prefs(c).edit().putString(errorKey, msg).apply()
        return msg
    }

    private fun download(pageUrl: String): String {
        val conn = URL(pageUrl).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
            )
            val code = conn.responseCode
            if (code != 200) throw IOException("HTTP $code")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
        } finally {
            conn.disconnect()
        }
    }
}
