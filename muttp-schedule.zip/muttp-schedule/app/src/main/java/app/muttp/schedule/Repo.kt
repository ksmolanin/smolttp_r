package app.muttp.schedule

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Скачивание, проверка и хранение. В файле лежит сырой HTML последней удачной загрузки. */
object Repo {
    private const val PAGE_URL = "https://muttp.ru/raspisanie-dvizheniya-avtobusov/"
    private const val FILE = "schedule.html"
    private const val STALE_MS = 20L * 3600 * 1000
    const val ERR_NET = "Ошибка интернета"

    private fun prefs(c: Context) = c.getSharedPreferences("schedule", Context.MODE_PRIVATE)

    fun updatedMs(c: Context): Long = prefs(c).getLong("updated_ms", 0L)
    fun lastError(c: Context): String? = prefs(c).getString("last_error", null)
    fun isStale(c: Context): Boolean = System.currentTimeMillis() - updatedMs(c) > STALE_MS

    fun load(c: Context): Schedule? {
        val f = File(c.filesDir, FILE)
        if (!f.exists()) return null
        return try {
            Tweaks.apply(Merger.apply(Parser.parse(f.readText())))
        } catch (e: Exception) {
            null
        }
    }

    /** Возвращает null при успехе или текст ошибки. Старая версия при ошибке не трогается. */
    fun update(c: Context): String? {
        return try {
            val html = download()
            val problems = Validator.validate(Parser.parse(html))
            if (problems.isNotEmpty()) {
                return fail(c, "сайт изменился, парсер не сработал (" + problems.take(3).joinToString("; ") + ")")
            }
            val cur = File(c.filesDir, FILE)
            val tmp = File(c.filesDir, "$FILE.tmp")
            tmp.writeText(html)
            tmp.copyTo(cur, overwrite = true)
            tmp.delete()
            prefs(c).edit()
                .putLong("updated_ms", System.currentTimeMillis())
                .remove("last_error")
                .apply()
            null
        } catch (e: java.io.IOException) {
            fail(c, ERR_NET)
        } catch (e: Exception) {
            fail(c, e.message ?: e.javaClass.simpleName)
        }
    }

    private fun fail(c: Context, msg: String): String {
        prefs(c).edit().putString("last_error", msg).apply()
        return msg
    }

    private fun download(): String {
        val conn = URL(PAGE_URL).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
            )
            val code = conn.responseCode
            if (code != 200) throw java.io.IOException("HTTP $code")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
        } finally {
            conn.disconnect()
        }
    }
}
