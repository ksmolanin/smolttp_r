package app.muttp.schedule

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

/** Смоленск живёт по московскому времени; зона задана явно, а не берётся из настроек телефона. */
val MSK: ZoneId = ZoneId.of("Europe/Moscow")

object Scheduler {
    private const val NAME = "daily_update"
    private val RUN_AT = LocalTime.of(5, 20)

    private fun delayToNext(): Duration {
        val now = ZonedDateTime.now(MSK)
        var next = now.with(RUN_AT)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return Duration.between(now, next)
    }

    /** При старте приложения: если запуск уже запланирован, ничего не меняем. */
    fun ensureScheduled(ctx: Context) = enqueue(ctx, ExistingWorkPolicy.KEEP)

    /** Из воркера после отработки: следующий запуск на завтра 5:20. */
    fun scheduleNext(ctx: Context) = enqueue(ctx, ExistingWorkPolicy.APPEND_OR_REPLACE)

    private fun enqueue(ctx: Context, policy: ExistingWorkPolicy) {
        val request = OneTimeWorkRequestBuilder<UpdateWorker>()
            .setInitialDelay(delayToNext())
            .setConstraints(
                Constraints.Builder().setRequiredNetworkType(NetworkType.UNMETERED).build()
            )
            .setBackoffCriteria(BackoffPolicy.LINEAR, 10, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(NAME, policy, request)
    }
}

class UpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val error = withContext(Dispatchers.IO) { Repo.update(applicationContext) }
        // до 4 повторов с шагом 10 минут; потом сдаёмся до завтра
        if (error != null && runAttemptCount < 4) return Result.retry()
        Scheduler.scheduleNext(applicationContext)
        return Result.success()
    }
}
