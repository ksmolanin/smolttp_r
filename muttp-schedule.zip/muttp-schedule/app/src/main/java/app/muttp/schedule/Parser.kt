package app.muttp.schedule

import org.jsoup.Jsoup

/**
 * Разбор страницы https://muttp.ru/raspisanie-dvizheniya-avtobusov/
 * Берутся только секции «Рабочие дни — город» и «Выходные дни — город».
 * Пригород и дачные пропускаются.
 *
 * Идём по элементам подряд и ведём состояние: секция -> маршрут -> остановка -> времена.
 * Так не важно, как страница разбита на <p>.
 */
object Parser {
    private val timeRe = Regex("""(\d{1,2})[.:,](\d{2})(\*)?""")
    private val routeRe = Regex("""№\s*(\d+[A-Za-zА-Яа-яЁё]*)""")
    private val spaces = Regex("""\s+""")

    internal val routeOrder = compareBy<Route>(
        { it.number.takeWhile { c -> c.isDigit() }.toIntOrNull() ?: 0 },
        { it.number }
    )

    fun parse(html: String): Schedule {
        val doc = Jsoup.parse(html)
        val post = doc.selectFirst("div.content div.post")
            ?: error("Не найден блок div.content div.post")

        val weekday = mutableListOf<Route>()
        val weekend = mutableListOf<Route>()
        var target: MutableList<Route>? = null
        var route: Route? = null
        var stop: Stop? = null

        for (el in post.children()) {
            when (el.tagName()) {
                "h4" -> {
                    val t = el.text().lowercase()
                    target = when {
                        "пригород" in t || "дач" in t || "город" !in t -> null
                        "рабоч" in t -> weekday
                        "выходн" in t -> weekend
                        else -> null
                    }
                    route = null
                    stop = null
                }
                "p" -> {
                    val list = target ?: continue
                    el.select("br").after("\n")
                    val lines = el.wholeText().replace('\u00A0', ' ').split('\n')
                    for (raw in lines) {
                        val line = spaces.replace(raw, " ").trim()
                        if (line.isEmpty()) continue
                        val hasTime = timeRe.containsMatchIn(line)
                        when {
                            // остановка: ===== название =====
                            line.startsWith("=") -> {
                                val r = route
                                if (r != null) {
                                    val s = Stop(line.trim('=', ' ').ifEmpty { "—" })
                                    r.stops.add(s)
                                    stop = s
                                }
                            }
                            // сноска: "* — в гараж", "-* с заездом в Пасово"
                            (line.startsWith("*") || line.startsWith("-*")) && !hasTime -> {
                                route?.notes?.add(line.trimStart('-', '*', '—', '–', ' ').trim())
                            }
                            // заголовок маршрута: "Маршрут № 3 ..." или просто "№ 22 ..."
                            !hasTime && routeRe.containsMatchIn(line) -> {
                                val m = routeRe.find(line)!!
                                val r = Route(m.groupValues[1].lowercase(), cleanTitle(line))
                                list.add(r)
                                route = r
                                stop = null
                            }
                            // строка времён
                            hasTime -> {
                                val r = route
                                if (r != null) {
                                    var s = stop
                                    if (s == null) {
                                        s = Stop("")
                                        r.stops.add(s)
                                        stop = s
                                    }
                                    for (m in timeRe.findAll(line)) {
                                        s.times.add(
                                            Dep(
                                                m.groupValues[1].toInt(),
                                                m.groupValues[2].toInt(),
                                                m.groupValues[3].isNotEmpty()
                                            )
                                        )
                                    }
                                }
                            }
                            // продолжение названия маршрута (бывает разорвано на строки)
                            else -> {
                                val r = route
                                if (r != null && r.stops.isEmpty() && line != "Маршрут") {
                                    r.title = (r.title + " " + line).trim()
                                }
                            }
                        }
                    }
                }
            }
        }
        weekday.sortWith(routeOrder)
        weekend.sortWith(routeOrder)
        return Schedule(weekday, weekend)
    }

    private fun cleanTitle(line: String): String =
        line.replace(Regex("""^Маршрут\s*"""), "")
            .replaceFirst(routeRe, "")
            .trim()
}

/**
 * Проверка результата перед заменой сохранённой версии.
 * Если сайт поменялся, старые данные остаются, а в приложении видна ошибка.
 * Список ожидаемых маршрутов: если добавишь/уберёшь маршрут, поправь тут.
 */
object Validator {
    private val WEEKDAY = setOf(
        "3", "7", "8", "9", "11", "12", "14", "15", "19", "22", "24", "24д",
        "25", "28", "30", "31", "31к", "33", "34", "50", "53", "53д", "54"
    )
    private val WEEKEND = setOf(
        "3", "7", "8", "11", "12", "14", "15", "19", "22", "24",
        "25", "28", "30", "31", "31к", "33", "34", "50", "53", "54"
    )

    fun validate(s: Schedule): List<String> {
        val problems = mutableListOf<String>()
        validateDay("будни", s.weekday, WEEKDAY, problems)
        validateDay("выходные", s.weekend, WEEKEND, problems)
        return problems
    }

    private fun validateDay(
        label: String,
        routes: List<Route>,
        expected: Set<String>,
        out: MutableList<String>
    ) {
        val nums = routes.map { it.number }
        val missing = expected - nums.toSet()
        if (missing.isNotEmpty()) out.add("$label: нет маршрутов ${missing.sorted().joinToString(",")}")
        if (nums.size != nums.toSet().size) out.add("$label: повтор номера маршрута")
        for (r in routes) {
            if (r.stops.none { it.times.isNotEmpty() }) out.add("$label: у маршрута ${r.number} нет времён")
            for (st in r.stops) for (d in st.times) {
                if (d.hour > 23 || d.minute > 59) out.add("$label: маршрут ${r.number}, странное время ${d.label()}")
            }
        }
    }
}
