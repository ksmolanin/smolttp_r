@file:OptIn(
    ExperimentalSharedTransitionApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalMaterial3Api::class
)

package app.muttp.schedule

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class UiState(
    val schedule: Schedule? = null,
    val updatedMs: Long = 0L,
    val error: String? = null,
    val tram: Schedule? = null,
    val tramUpdatedMs: Long = 0L,
    val tramError: String? = null,
    val trolley: Schedule? = null,
    val trolleyUpdatedMs: Long = 0L,
    val trolleyError: String? = null,
    val busy: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var ui by mutableStateOf(UiState())
        private set

    private val ctx: Application get() = getApplication()

    private fun load(): UiState = UiState(
        schedule = Repo.load(ctx),
        updatedMs = Repo.updatedMs(ctx),
        error = Repo.lastError(ctx),
        tram = Repo.loadTram(ctx),
        tramUpdatedMs = Repo.tramUpdatedMs(ctx),
        tramError = Repo.tramLastError(ctx),
        trolley = Repo.loadTrolley(ctx),
        trolleyUpdatedMs = Repo.trolleyUpdatedMs(ctx),
        trolleyError = Repo.trolleyLastError(ctx)
    )

    init {
        viewModelScope.launch {
            ui = withContext(Dispatchers.IO) { load() }
            // нет данных или они старше 20 часов: пробуем обновить при открытии
            if (ui.schedule == null || ui.tram == null || ui.trolley == null || Repo.isStale(ctx)) refresh()
        }
    }

    fun refresh() {
        if (ui.busy) return
        viewModelScope.launch {
            ui = UiState(
                ui.schedule, ui.updatedMs, ui.error,
                ui.tram, ui.tramUpdatedMs, ui.tramError,
                ui.trolley, ui.trolleyUpdatedMs, ui.trolleyError,
                busy = true
            )
            withContext(Dispatchers.IO) { Repo.update(ctx) }
            ui = withContext(Dispatchers.IO) { load() }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppRoot() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun isWeekendToday(): Boolean {
    val d = ZonedDateTime.now(MSK).dayOfWeek
    return d == DayOfWeek.SATURDAY || d == DayOfWeek.SUNDAY
}

/** Положение в приложении: раздел (null = главный экран) и открытый маршрут внутри «Автобусов». */
data class Nav(val section: String?, val route: String?)

/**
 * Экраны: главный (4 раздела), список автобусных маршрутов, окно маршрута, заглушки.
 * Номер и направление «переезжают» с плитки в шапку окна маршрута (shared element).
 */
@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val ui = vm.ui
    var tab by rememberSaveable { mutableIntStateOf(if (isWeekendToday()) 1 else 0) }
    var section by rememberSaveable { mutableStateOf<String?>(null) }
    var openNumber by rememberSaveable { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val miniListState = rememberLazyListState()
    val appCtx = LocalContext.current
    var pinnedBus by remember { mutableStateOf(Favorites.load(appCtx, "bus")) }
    var pinnedMini by remember { mutableStateOf(Favorites.load(appCtx, "minibus")) }
    var unreadNotices by remember { mutableIntStateOf(NotificationsRepo.unreadCount(appCtx)) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { NotificationsRepo.update(appCtx) }
        unreadNotices = NotificationsRepo.unreadCount(appCtx)
    }
    val miniSchedule = remember { Minibus.build() }
    val tramListState = rememberLazyListState()
    val trolleyListState = rememberLazyListState()
    val tramStub = remember { TramBuilder.stub() }
    val routes = ui.schedule?.let { if (tab == 0) it.weekday else it.weekend }.orEmpty()
    val miniRoutes = if (tab == 0) miniSchedule.weekday else miniSchedule.weekend
    val tramRoutes = (ui.tram?.let { if (tab == 0) it.weekday else it.weekend }.orEmpty() + tramStub)
        .sortedBy { it.number }
    val trolleyRoutes = ui.trolley?.let { if (tab == 0) it.weekday else it.weekend }.orEmpty()

    BackHandler(enabled = section != null || openNumber != null) {
        if (openNumber != null) openNumber = null else section = null
    }

    SharedTransitionLayout {
        AnimatedContent(
            targetState = Nav(section, openNumber),
            transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
            label = "screen"
        ) { nav ->
            when (nav.section) {
                null -> HomeScreen(onOpen = { section = it }, onSettings = { section = "settings" }, hasUnread = unreadNotices > 0)
                "settings" -> NotificationsScreen(onBack = { section = null }, onUnreadChanged = { unreadNotices = it })
                "contacts" -> ContactsScreen(onBack = { section = null })
                "bus", "minibus", "tram", "trolley" -> {
                    val kind = nav.section
                    val sectionRoutes = when (kind) {
                        "bus" -> routes.pinnedFirst(pinnedBus)
                        "minibus" -> miniRoutes.pinnedFirst(pinnedMini)
                        "tram" -> tramRoutes
                        else -> trolleyRoutes
                    }
                    val route = if (nav.route == null) null else sectionRoutes.firstOrNull { it.number == nav.route }
                    if (route == null) {
                        RouteListScreen(
                            anim = this@AnimatedContent,
                            title = when (kind) {
                                "bus" -> "Автобусы"
                                "minibus" -> "Маршрутки"
                                "tram" -> "Трамваи"
                                else -> "Троллейбусы"
                            },
                            showUpdate = kind != "minibus",
                            busy = ui.busy,
                            error = when (kind) {
                                "tram" -> ui.tramError
                                "trolley" -> ui.trolleyError
                                else -> ui.error
                            },
                            updatedMs = when (kind) {
                                "tram" -> ui.tramUpdatedMs
                                "trolley" -> ui.trolleyUpdatedMs
                                else -> ui.updatedMs
                            },
                            hasData = when (kind) {
                                "tram" -> ui.tram != null
                                "trolley" -> ui.trolley != null
                                else -> ui.schedule != null
                            },
                            routes = sectionRoutes,
                            tab = tab,
                            listState = when (kind) {
                                "bus" -> listState
                                "minibus" -> miniListState
                                "tram" -> tramListState
                                else -> trolleyListState
                            },
                            onTab = { tab = it },
                            onRefresh = { vm.refresh() },
                            onOpen = { openNumber = it },
                            onBack = { section = null; openNumber = null }
                        )
                    } else {
                        RouteDetailScreen(
                            anim = this@AnimatedContent,
                            r = route,
                            onBack = { openNumber = null },
                            section = kind,
                            // список остановок (три полоски): все разделы
                            stopData = StopLists.get(kind, route.number),
                            // ближайший рейс выделяется у автобусов, трамваев и троллейбусов
                            highlight = kind != "minibus" && tab == (if (isWeekendToday()) 1 else 0),
                            // «Закрепить» есть только у автобусов и маршруток
                            pinned = when (kind) {
                                "bus" -> route.number in pinnedBus
                                "minibus" -> route.number in pinnedMini
                                else -> null
                            },
                            onTogglePin = {
                                if (kind == "bus") {
                                    pinnedBus = togglePin(pinnedBus, route.number)
                                    Favorites.save(appCtx, "bus", pinnedBus)
                                } else if (kind == "minibus") {
                                    pinnedMini = togglePin(pinnedMini, route.number)
                                    Favorites.save(appCtx, "minibus", pinnedMini)
                                }
                            }
                        )
                    }
                }
                else -> EmptyScreen(title = sectionTitle(nav.section), onBack = { section = null })
            }
        }
    }
}

private fun sectionTitle(section: String?): String = when (section) {
    "minibus" -> "Маршрутки"
    "tram" -> "Трамваи"
    "trolley" -> "Троллейбусы"
    else -> ""
}

/** Главный экран: четыре раздела. Логотипы позже. */
@Composable
fun HomeScreen(onOpen: (String) -> Unit, onSettings: () -> Unit, hasUnread: Boolean = false) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Расписание транспорта") },
                navigationIcon = {
                    IconButton(onClick = onSettings) {
                        Box {
                            Text("☰", style = MaterialTheme.typography.headlineSmall)
                            if (hasUnread) {
                                Box(
                                    Modifier.align(Alignment.TopEnd).padding(top = 1.dp, end = 1.dp)
                                        .width(9.dp).height(9.dp).background(MaterialTheme.colorScheme.error, CircleShape)
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // плитки занимают всё, что осталось над блоком контактов
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeTile("Автобусы", Color(0xFFFFEFB0), Modifier.weight(1f)) { onOpen("bus") }
                HomeTile("Маршрутки", Color(0xFFCBD8E6), Modifier.weight(1f)) { onOpen("minibus") }
                HomeTile("Трамваи", Color(0xFFF4C9C9), Modifier.weight(1f)) { onOpen("tram") }
                HomeTile("Троллейбусы", Color(0xFFCDEBC6), Modifier.weight(1f)) { onOpen("trolley") }
                HomeTile("Информация", Color(0xFFDDD8EE), Modifier.weight(0.7f)) { onOpen("contacts") }
            }
        }
    }
}

/** Раздел уведомлений: объявления с muttp.ru, новые записи подсвечиваются до первого нажатия. */
@Composable
fun NotificationsScreen(onBack: () -> Unit, onUnreadChanged: (Int) -> Unit) {
    val ctx = LocalContext.current
    var notices by remember { mutableStateOf(NotificationsRepo.load(ctx)) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var readIds by remember { mutableStateOf(ctx.getSharedPreferences("muttp_notices", Context.MODE_PRIVATE).getStringSet("read_ids", emptySet()).orEmpty()) }
    val scope = rememberCoroutineScope()

    fun syncRead() {
        readIds = ctx.getSharedPreferences("muttp_notices", Context.MODE_PRIVATE).getStringSet("read_ids", emptySet()).orEmpty()
        onUnreadChanged(NotificationsRepo.unreadCount(ctx))
    }
    LaunchedEffect(Unit) {
        busy = true
        error = withContext(Dispatchers.IO) { NotificationsRepo.update(ctx) }
        notices = NotificationsRepo.load(ctx)
        busy = false
        syncRead()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Уведомления") },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Объявления МУТТП", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(
                    onClick = {
                        NotificationsRepo.markAllRead(ctx)
                        syncRead()
                    },
                    enabled = !busy && notices.any { it.id !in readIds }
                ) { Text("Прочитать все") }
                TextButton(onClick = {
                    if (!busy) scope.launch {
                        busy = true
                        error = withContext(Dispatchers.IO) { NotificationsRepo.update(ctx) }
                        notices = NotificationsRepo.load(ctx)
                        busy = false
                        syncRead()
                    }
                }, enabled = !busy) { Text(if (busy) "Загрузка…" else "Обновить") }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { Text("Не удалось обновить: $it", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 12.dp)) }
            if (notices.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (busy) "Загружаем объявления…" else "Объявлений пока нет")
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(notices, key = { it.id }) { notice ->
                        val isUnread = notice.id !in readIds
                        Card(
                            Modifier.fillMaxWidth().clickable {
                                NotificationsRepo.markRead(ctx, notice.id)
                                syncRead()
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnread) Color(0xFFDDF2DF) else MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(notice.text, style = MaterialTheme.typography.bodyMedium)
                                if (isUnread) Text("Новое · нажмите, чтобы отметить прочитанным", style = MaterialTheme.typography.labelSmall, color = Color(0xFF287A35))
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Страница «Информация»: открывается плиткой на главном экране. */
@Composable
fun ContactsScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Информация") },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ContactsCard()
            LinksCard()
            DeveloperCard()
        }
    }
}

private fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: ActivityNotFoundException) {
        // нет браузера, ничего не делаем
    }
}

/** Полезные ссылки: две кнопки, без упоминания адресов сайтов в подписях. */
@Composable
fun LinksCard() {
    val ctx = LocalContext.current
    val panel = MaterialTheme.colorScheme.surfaceVariant
    val darker = lerp(panel, Color.Black, 0.10f)
    val textColor = MaterialTheme.colorScheme.onSurfaceVariant
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = panel)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ContactButton("Вывод карты из Стоп-Листа", darker, textColor, Modifier.fillMaxWidth()) {
                openUrl(ctx, Contacts.STOPLIST_URL)
            }
            ContactButton("Получить фискальный чек", darker, textColor, Modifier.fillMaxWidth()) {
                openUrl(ctx, Contacts.RECEIPT_URL)
            }
        }
    }
}

/** Связь с разработчиком: почта спрятана под кнопкой и копируется по нажатию. */
@Composable
fun DeveloperCard() {
    val ctx = LocalContext.current
    val panel = MaterialTheme.colorScheme.surfaceVariant
    val darker = lerp(panel, Color.Black, 0.10f)
    val textColor = MaterialTheme.colorScheme.onSurfaceVariant
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(2000)
            copied = false
        }
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = panel)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Связаться с разработчиком", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Button(
                onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("email", Contacts.EMAIL))
                    copied = true
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = darker, contentColor = textColor)
            ) {
                Text(if (copied) "Почта скопирована ✓" else Contacts.EMAIL)
            }
        }
    }
}

/** Кнопка-ссылка внутри блока контактов. */
@Composable
fun ContactButton(text: String, container: Color, content: Color, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content)
    ) {
        Text(text, textDecoration = TextDecoration.Underline)
    }
}

/**
 * Блок контактов: адреса, телефоны диспетчера, сайт. Данные в Contacts.kt.
 * Каждый пункт на отдельной плашке чуть темнее самой панели. Телефон открывает набор номера
 * (без звонка), сайт открывается в браузере.
 */
@Composable
fun ContactsCard() {
    val ctx = LocalContext.current
    val panel = MaterialTheme.colorScheme.surfaceVariant
    val darker = lerp(panel, Color.Black, 0.10f)
    val textColor = MaterialTheme.colorScheme.onSurfaceVariant
    val open: (Intent) -> Unit = { intent ->
        try {
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            // нет подходящего приложения, ничего не делаем
        }
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = panel)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("МУТТП", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (a in Contacts.addresses) {
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = darker)) {
                        Text(
                            a,
                            Modifier.fillMaxWidth().padding(10.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
            Text("Центральный диспетчер", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            for (p in Contacts.phones) {
                ContactButton("${p.label} ${p.display}", darker, textColor, Modifier.fillMaxWidth()) {
                    open(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.dial}")))
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Сайт:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                ContactButton(Contacts.SITE, darker, textColor, Modifier.weight(1f)) {
                    open(Intent(Intent.ACTION_VIEW, Uri.parse("https://" + Contacts.SITE)))
                }
            }
        }
    }
}

@Composable
fun HomeTile(title: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color, contentColor = Color(0xFF2B2B2B))
    ) {
        Box(
            Modifier.fillMaxSize().clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun EmptyScreen(title: String, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Пока пусто", style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
fun SharedTransitionScope.RouteListScreen(
    anim: AnimatedVisibilityScope,
    title: String,
    showUpdate: Boolean,
    busy: Boolean,
    error: String?,
    updatedMs: Long,
    hasData: Boolean,
    routes: List<Route>,
    tab: Int,
    listState: LazyListState,
    onTab: (Int) -> Unit,
    onRefresh: () -> Unit,
    onOpen: (String) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (showUpdate) {
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                UpdateBar(busy, error, updatedMs, hasData, onRefresh)
            }
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { onTab(0) }, text = { Text("Будни") })
                Tab(selected = tab == 1, onClick = { onTab(1) }, text = { Text("Выходные") })
            }
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(routes) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        RouteHeader(r, anim, Modifier.clickable { onOpen(r.number) })
                    }
                }
            }
        }
    }
}

/** Окно маршрута. Сюда позже добавится дополнительная информация о маршруте. */
@Composable
fun SharedTransitionScope.RouteDetailScreen(
    anim: AnimatedVisibilityScope,
    r: Route,
    onBack: () -> Unit,
    pinned: Boolean? = null,
    onTogglePin: () -> Unit = {},
    section: String = "",
    stopData: StopLists.Data? = null,
    highlight: Boolean = false
) {
    var showStops by rememberSaveable { mutableStateOf(false) }
    var dirIndex by rememberSaveable { mutableIntStateOf(0) }
    var variantIndex by rememberSaveable { mutableIntStateOf(0) }
    var favoritesRevision by rememberSaveable { mutableIntStateOf(0) }
    val context = LocalContext.current
    val chosenVariant = if (variantIndex in 1..(stopData?.variants?.size ?: 0)) stopData!!.variants[variantIndex - 1] else null
    val directionLists = stopData?.let { listOf(chosenVariant?.forward ?: it.forward, chosenVariant?.reverse ?: it.reverse) }.orEmpty()
    val siteStopsByDirection = directionLists.mapIndexed { directionIndex, names ->
        when (section) {
            "bus" -> setOfNotNull(names.firstOrNull())
            "tram", "trolley" -> (r.groups.firstOrNull { group -> group.stops.any { (FavoriteStops.normalize(it.name.substringBefore(" - ")).contains(FavoriteStops.normalize(names.first())) || FavoriteStops.normalize(names.first()).contains(FavoriteStops.normalize(it.name.substringBefore(" - ")))) } } ?: r.groups.getOrNull(directionIndex))?.stops.orEmpty().map { it.name.substringBefore(" - ").trim() }.filter { it.isNotBlank() }.toSet()
            else -> emptySet()
        }
    }
    // жест «назад» сначала закрывает панель остановок
    BackHandler(enabled = showStops) { showStops = false }
    Box(Modifier.fillMaxSize()) {
        RouteDetailBody(anim, r, onBack, pinned, onTogglePin, stopData != null, highlight, section, stopData, variantIndex, favoritesRevision) { showStops = true }
        if (stopData != null) {
            StopsPanel(showStops, section, r.number, stopData, dirIndex, { dirIndex = it }, variantIndex, { variantIndex = it }, siteStopsByDirection.getOrNull(dirIndex).orEmpty(), favoritesRevision, { favoritesRevision++ }) {
                showStops = false
            }
        }
    }
}

/**
 * Панель остановок: выезжает справа на 90% ширины, слева остаётся затемнённый экран.
 * Переключатели направления и варианта, ниже список остановок с выбором избранных двойным нажатием.
 */
@Composable
fun BoxScope.StopsPanel(
    visible: Boolean,
    section: String,
    number: String,
    data: StopLists.Data,
    dir: Int,
    onDir: (Int) -> Unit,
    variant: Int,
    onVariant: (Int) -> Unit,
    siteStops: Set<String>,
    favoritesRevision: Int,
    onFavoritesChanged: () -> Unit,
    onClose: () -> Unit
) {
    AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.45f))
                .clickable(onClick = onClose)
        )
    }
    AnimatedVisibility(
        visible = visible,
        modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(0.9f),
        enter = slideInHorizontally(initialOffsetX = { it }),
        exit = slideOutHorizontally(targetOffsetX = { it })
    ) {
        // вариант маршрута (0 = основной): меняет списки остановок обоих направлений
        val chosen = if (variant in 1..data.variants.size) data.variants[variant - 1] else null
        val dirs = listOf(chosen?.forward ?: data.forward, chosen?.reverse ?: data.reverse)
        val current = dirs[dir.coerceIn(0, dirs.size - 1)]
        Surface(
            Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp),
            tonalElevation = 6.dp
        ) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Остановки", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onClose) { Text("✕") }
                }
                Spacer(Modifier.height(8.dp))
                for ((i, d) in dirs.withIndex()) {
                    val label = "в направлении " + d.last()
                    if (i == dir) {
                        Button(onClick = { onDir(i) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
                    } else {
                        OutlinedButton(onClick = { onDir(i) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                if (data.variants.isNotEmpty()) {
                    Text("Вариант маршрута", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(4.dp))
                    val options = listOf("Основной") + data.variants.map { it.title }
                    for ((i, title) in options.withIndex()) {
                        if (i == variant) {
                            // тот же цвет, что у переключателей направлений
                            Button(onClick = { onVariant(i) }, modifier = Modifier.fillMaxWidth()) { Text(title) }
                        } else {
                            OutlinedButton(onClick = { onVariant(i) }, modifier = Modifier.fillMaxWidth()) { Text(title) }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                HorizontalDivider()
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    val kashena = !(section == "minibus" && number == "21")
                    val context = LocalContext.current
                    val selectedStops = remember(favoritesRevision, section, number, variant, dir, current, siteStops) {
                        FavoriteStops.selected(context, section, number, variant, dir, current, siteStops)
                    }
                    if (section != "minibus") Text("Дважды нажмите на остановку, чтобы включить или отключить её", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    current.forEachIndexed { i, name ->
                        val terminal = i == 0 || i == current.lastIndex
                        val enabled = name in selectedStops
                        val isStud = kashena && (name == "Студенческая ул." || name == "ул. Студенческая")
                        if (isStud) {
                            Row(
                                Modifier.fillMaxWidth().pointerInput(section, number, variant, dir, name, enabled) {
                                    if (section != "minibus") detectTapGestures(onDoubleTap = {
                                        val error = FavoriteStops.toggle(context, section, number, variant, dir, current, siteStops, i)
                                        if (error == null) onFavoritesChanged()
                                        else Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                                    })
                                }.padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "ул. Кашена",
                                    style = MaterialTheme.typography.bodyLarge,
                                    textDecoration = TextDecoration.LineThrough,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(name, style = MaterialTheme.typography.bodyLarge, fontWeight = if (terminal) FontWeight.Bold else null)
                                if (section != "minibus") Text(if (enabled) "✓" else "○", modifier = Modifier.padding(start = 8.dp), color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                            }
                        } else {
                            val note = when {
                                section == "minibus" && number == "9н" && name == "Полевая ул." && current.lastOrNull() == "Садки" -> "по требованию"
                                section == "minibus" && number == "9н" && name == "Полевая ул." && current.lastOrNull() == "Колхозный пер." -> "с 7 до 9 и с 17 по 19"
                                section == "tram" && name == "Гражданстрой" -> "депо"
                                else -> null
                            }
                            Row(
                                Modifier.fillMaxWidth().pointerInput(section, number, variant, dir, name, enabled) {
                                    if (section != "minibus") detectTapGestures(onDoubleTap = {
                                        val error = FavoriteStops.toggle(context, section, number, variant, dir, current, siteStops, i)
                                        if (error == null) onFavoritesChanged()
                                        else Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                                    })
                                }.padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    name,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (terminal) FontWeight.Bold else null,
                                    color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (section != "minibus") Text(if (enabled) "✓" else "○", modifier = Modifier.padding(start = 8.dp), color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                                if (note != null) {
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        note,
                                        style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        HorizontalDivider(thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}

@Composable
fun SharedTransitionScope.RouteDetailBody(
    anim: AnimatedVisibilityScope,
    r: Route,
    onBack: () -> Unit,
    pinned: Boolean?,
    onTogglePin: () -> Unit,
    hasStops: Boolean,
    highlight: Boolean,
    section: String,
    stopData: StopLists.Data?,
    variantIndex: Int,
    favoritesRevision: Int,
    onShowStops: () -> Unit
) {
    // ближайшее время выделяется только для сегодняшнего расписания (вкладка совпадает с сегодняшним днём)
    val nowMin = if (highlight) rememberMoscowMinute() else null
    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } },
                actions = {
                    if (hasStops) {
                        IconButton(onClick = onShowStops) {
                            Text("☰", style = MaterialTheme.typography.headlineSmall)
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                RouteHeader(r, anim, Modifier)
            }
            if (pinned != null) {
                FilledTonalButton(
                    onClick = onTogglePin,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Закрепить")
                        Checkbox(checked = pinned, onCheckedChange = null)
                    }
                }
                if (section == "bus" && r.number in setOf("50", "53")) {
                    Text(
                        "Из-за ремонта ул. Кашена могут быть задержки в расписании",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                if (r.info.isNotEmpty()) {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            r.info.forEachIndexed { i, line ->
                                if (i == 0) {
                                    Text(line, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                } else {
                                    Text(line, style = MaterialTheme.typography.bodyLarge)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                // плитки направлений (троллейбусы): чуть темнее фона, расписания раздельно по сторонам
                for (g in r.groups) {
                    val darker = lerp(MaterialTheme.colorScheme.surfaceVariant, Color.Black, 0.08f)
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (g.title.isNotEmpty()) {
                                Text(g.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            for (s in g.stops) {
                                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = darker)) {
                                    Column(Modifier.padding(10.dp)) { StopBlock(s, nowMin) }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                // Если у маршрута одна сноска и в расписании есть рейсы со звёздочкой,
                // сноска стоит под тем списком, где эти звёздочки. Иначе сноски внизу.
                val single = r.notes.distinct().singleOrNull()
                val notesUnderStops = single != null && r.stops.any { st -> st.times.any { it.starred } }
                val lastStarred = r.stops.lastOrNull { st -> st.times.any { it.starred } }
                for (s in r.stops) {
                    if (s.times.isEmpty()) continue
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            StopBlock(s, nowMin)
                            if (notesUnderStops && s.times.any { it.starred } && (!r.noteOnce || s === lastStarred)) {
                                Text("* $single", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                // Избранные остановки: времена рассчитываются от исходного рейса по минутам из реестра.
                if (section != "minibus" && stopData != null) {
                    val context = LocalContext.current
                    val variant = variantIndex
                    val chosenVariant = if (variant in 1..stopData.variants.size) stopData.variants[variant - 1] else null
                    val paths = listOf(chosenVariant?.forward ?: stopData.forward, chosenVariant?.reverse ?: stopData.reverse)
                    for (direction in 0..1) {
                        val names = paths[direction]
                        val siteStops = when (section) {
                            "bus" -> setOfNotNull(names.firstOrNull())
                            "tram", "trolley" -> (r.groups.firstOrNull { group -> group.stops.any { (FavoriteStops.normalize(it.name.substringBefore(" - ")).contains(FavoriteStops.normalize(names.first())) || FavoriteStops.normalize(names.first()).contains(FavoriteStops.normalize(it.name.substringBefore(" - ")))) } } ?: r.groups.getOrNull(direction))?.stops.orEmpty().map { it.name.substringBefore(" - ").trim() }.filter { it.isNotBlank() }.toSet()
                            else -> emptySet()
                        }
                        val selected = remember(favoritesRevision, section, r.number, variant, direction, names, siteStops) {
                            FavoriteStops.selected(context, section, r.number, variant, direction, names, siteStops)
                        }
                        val directionGroup = r.groups.firstOrNull { group -> group.stops.any { (FavoriteStops.normalize(it.name.substringBefore(" - ")).contains(FavoriteStops.normalize(names.first())) || FavoriteStops.normalize(names.first()).contains(FavoriteStops.normalize(it.name.substringBefore(" - ")))) } } ?: r.groups.getOrNull(direction)
                        val source = if (section == "bus") {
                            r.stops.firstOrNull { FavoriteStops.normalize(it.name).contains(FavoriteStops.normalize(names.first())) || FavoriteStops.normalize(names.first()).contains(FavoriteStops.normalize(it.name)) }
                        } else {
                            directionGroup?.stops?.firstOrNull { (FavoriteStops.normalize(it.name.substringBefore(" - ")).contains(FavoriteStops.normalize(names.first())) || FavoriteStops.normalize(names.first()).contains(FavoriteStops.normalize(it.name.substringBefore(" - ")))) }
                        }
                        val siteSources = if (section == "bus") listOfNotNull(source) else directionGroup?.stops.orEmpty()
                        val calculated = FavoriteStops.arrivalStops(context, section, r.number, direction, selected, source, siteSources, variant)
                        if (calculated.isNotEmpty()) {
                            Text("Избранные остановки — ${names.first()} → ${names.last()}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            for (favorite in calculated) {
                                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                    Column(Modifier.padding(12.dp)) { StopBlock(favorite, nowMin) }
                                }
                                Spacer(Modifier.height(8.dp))
                            }
                        }
                    }
                }
                if (!notesUnderStops) {
                    for (n in r.notes.distinct()) {
                        Text("* $n", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(4.dp))
                    }
                }
                for (m in r.remarks) {
                    Text(m, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(4.dp))
                }
                // Здесь заканчивается прокручиваемое содержимое расписания.
            }
            // Контакт перевозчика вынесен в отдельную нижнюю область экрана,
            // чтобы не смешиваться с расписанием и примечаниями.
            if (section == "minibus") {
                MinibusCarrierCard(r.number)
            }
        }
    }
}

/** Контакт перевозчика маршрутки. Состав групп и номера редактируются в MinibusOwners.kt. */
@Composable
fun MinibusCarrierCard(routeNumber: String) {
    val carrier = remember(routeNumber) { MinibusOwners.forRoute(routeNumber) } ?: return
    val ctx = LocalContext.current
    val panel = MaterialTheme.colorScheme.surfaceVariant
    val darker = lerp(panel, Color.Black, 0.10f)
    val textColor = MaterialTheme.colorScheme.onSurfaceVariant
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = panel)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Перевозчик", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(carrier.owner, style = MaterialTheme.typography.bodyLarge)
            ContactButton(carrier.phone, darker, textColor, Modifier.fillMaxWidth()) {
                try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${carrier.dial}"))) }
                catch (_: ActivityNotFoundException) { }
            }
        }
    }
}

/** Московское время в минутах от начала суток (Смоленск живёт по Москве, часовой пояс телефона не важен). */
private fun moscowMinute(): Int {
    val t = ZonedDateTime.now(MSK)
    return t.hour * 60 + t.minute
}

/** Минуты суток по Москве; обновляется сам, пока открыт экран. */
@Composable
fun rememberMoscowMinute(): Int {
    val state = produceState(initialValue = moscowMinute()) {
        while (true) {
            delay(10_000)
            value = moscowMinute()
        }
    }
    return state.value
}

/**
 * Остановка отправления: название, уточнение, времена и сноски.
 * nowMin != null: ближайшее время выделяется жирным и крупнее, а если до него меньше трёх минут,
 * ещё крупнее. Время остаётся выделенным до конца своей минуты, затем выделяется следующее.
 */
@Composable
fun StopBlock(s: Stop, nowMin: Int? = null) {
    Text(
        s.name,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary
    )
    s.sub?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    val next = if (nowMin == null) null else {
        s.times.filter { it.hour * 60 + it.minute >= nowMin }.minByOrNull { it.hour * 60 + it.minute }
    }
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        for (d in s.times) {
            val isNext = d === next
            val urgent = isNext && nowMin != null && (d.hour * 60 + d.minute) - nowMin < 3
            Text(
                d.label(),
                fontFamily = FontFamily.Monospace,
                fontSize = when {
                    urgent -> 24.sp
                    isNext -> 20.sp
                    else -> 16.sp
                },
                fontWeight = if (isNext) FontWeight.Bold else null
            )
        }
    }
    for (f in s.footnotes) Text(f, style = MaterialTheme.typography.bodySmall)
}

/** Номер слева, направление справа по центру. Одинаковый вид в списке и в окне маршрута. */
@Composable
fun SharedTransitionScope.RouteHeader(r: Route, anim: AnimatedVisibilityScope, modifier: Modifier) {
    val lines = remember(r) { RouteNames.lines(r) }
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            r.number,
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier
                .width(88.dp)
                .sharedElement(rememberSharedContentState("num-${r.number}"), anim)
        )
        Column(
            Modifier
                .weight(1f)
                .sharedElement(rememberSharedContentState("dir-${r.number}"), anim),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            for (l in lines) FitText(l)
        }
    }
}

/** Одна строка крупным шрифтом; если не влезает в ширину, шрифт уменьшается до минимума. */
@Composable
fun FitText(text: String, maxSp: Float = 22f, minSp: Float = 10f) {
    var size by remember(text) { mutableFloatStateOf(maxSp) }
    Text(
        text,
        style = MaterialTheme.typography.titleLarge,
        fontSize = size.sp,
        textAlign = TextAlign.Center,
        maxLines = 1,
        softWrap = false,
        onTextLayout = { if (it.didOverflowWidth && size > minSp) size = (size - 1f).coerceAtLeast(minSp) }
    )
}

/**
 * Кнопка обновления с временем последнего обновления.
 * Свежие данные (меньше суток): цвет темы. Старше суток или данных нет: красная.
 */
@Composable
fun UpdateBar(busy: Boolean, error: String?, updatedMs: Long, hasData: Boolean, onRefresh: () -> Unit) {
    val fmt = remember { DateTimeFormatter.ofPattern("H:mm dd.MM") }
    val stale = !hasData || System.currentTimeMillis() - updatedMs > 24L * 3600 * 1000
    val label = when {
        busy -> "Обновление…"
        !hasData -> "Обновить"
        else -> "Обновлено " + Instant.ofEpochMilli(updatedMs).atZone(MSK).format(fmt)
    }
    val colors = if (stale) {
        ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error,
            contentColor = MaterialTheme.colorScheme.onError
        )
    } else {
        ButtonDefaults.buttonColors()
    }
    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
        Button(
            onClick = onRefresh,
            enabled = !busy,
            colors = colors,
            modifier = Modifier.fillMaxWidth()
        ) { Text(label) }
        error?.let {
            Text(
                if (it == Repo.ERR_NET) it else "Не удалось обновить: $it",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
