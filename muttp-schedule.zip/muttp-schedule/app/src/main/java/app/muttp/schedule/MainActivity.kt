@file:OptIn(
    ExperimentalSharedTransitionApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalMaterial3Api::class
)

package app.muttp.schedule

import android.app.Application
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class UiState(
    val schedule: Schedule? = null,
    val updatedMs: Long = 0L,
    val error: String? = null,
    val busy: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var ui by mutableStateOf(UiState())
        private set

    private val ctx: Application get() = getApplication()

    init {
        viewModelScope.launch {
            val s = withContext(Dispatchers.IO) { Repo.load(ctx) }
            ui = UiState(s, Repo.updatedMs(ctx), Repo.lastError(ctx))
            // нет данных или они старше 20 часов: пробуем обновить при открытии
            if (s == null || Repo.isStale(ctx)) refresh()
        }
    }

    fun refresh() {
        if (ui.busy) return
        viewModelScope.launch {
            ui = UiState(ui.schedule, ui.updatedMs, ui.error, busy = true)
            withContext(Dispatchers.IO) { Repo.update(ctx) }
            val s = withContext(Dispatchers.IO) { Repo.load(ctx) }
            ui = UiState(s, Repo.updatedMs(ctx), Repo.lastError(ctx))
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppRoot() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun isWeekendToday(): Boolean {
    val d = ZonedDateTime.now(MSK).dayOfWeek
    return d == DayOfWeek.SATURDAY || d == DayOfWeek.SUNDAY
}

/**
 * Два экрана: список плиток и окно маршрута.
 * Номер и направление «переезжают» с плитки в шапку окна (shared element),
 * остальное плавно проявляется.
 */
@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val ui = vm.ui
    var tab by rememberSaveable { mutableIntStateOf(if (isWeekendToday()) 1 else 0) }
    var openNumber by rememberSaveable { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val routes = ui.schedule?.let { if (tab == 0) it.weekday else it.weekend }.orEmpty()

    BackHandler(enabled = openNumber != null) { openNumber = null }

    SharedTransitionLayout {
        AnimatedContent(
            targetState = openNumber,
            transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
            label = "screen"
        ) { num ->
            val route = if (num == null) null else routes.firstOrNull { it.number == num }
            if (route == null) {
                RouteListScreen(
                    anim = this@AnimatedContent,
                    ui = ui,
                    routes = routes,
                    tab = tab,
                    listState = listState,
                    onTab = { tab = it },
                    onRefresh = { vm.refresh() },
                    onOpen = { openNumber = it }
                )
            } else {
                RouteDetailScreen(
                    anim = this@AnimatedContent,
                    r = route,
                    onBack = { openNumber = null }
                )
            }
        }
    }
}

@Composable
fun SharedTransitionScope.RouteListScreen(
    anim: AnimatedVisibilityScope,
    ui: UiState,
    routes: List<Route>,
    tab: Int,
    listState: LazyListState,
    onTab: (Int) -> Unit,
    onRefresh: () -> Unit,
    onOpen: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Расписание автобусов") },
                actions = {
                    TextButton(onClick = onRefresh, enabled = !ui.busy) { Text("Обновить") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (ui.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            StatusLine(ui)
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { onTab(0) }, text = { Text("Будни") })
                Tab(selected = tab == 1, onClick = { onTab(1) }, text = { Text("Выходные") })
            }
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(routes) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        RouteHeader(r, anim, Modifier.clickable { onOpen(r.number) })
                    }
                }
            }
        }
    }
}

/** Окно маршрута. Сюда позже добавится дополнительная информация о маршруте. */
@Composable
fun SharedTransitionScope.RouteDetailScreen(
    anim: AnimatedVisibilityScope,
    r: Route,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                RouteHeader(r, anim, Modifier)
            }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Если у маршрута одна сноска и в расписании есть рейсы со звёздочкой,
                // сноска стоит под тем списком, где эти звёздочки. Иначе сноски внизу.
                val single = r.notes.distinct().singleOrNull()
                val notesUnderStops = single != null && r.stops.any { st -> st.times.any { it.starred } }
                for (s in r.stops) {
                    if (s.times.isEmpty()) continue
                    Text(
                        s.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    s.sub?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall)
                    }
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        for (d in s.times) Text(d.label(), fontFamily = FontFamily.Monospace)
                    }
                    if (notesUnderStops && s.times.any { it.starred }) {
                        Text("* $single", style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(16.dp))
                }
                if (!notesUnderStops) {
                    for (n in r.notes.distinct()) {
                        Text("* $n", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(4.dp))
                    }
                }
                // сюда позже: дополнительная информация о маршруте
            }
        }
    }
}

/** Номер слева, направление справа по центру. Одинаковый вид в списке и в окне маршрута. */
@Composable
fun SharedTransitionScope.RouteHeader(r: Route, anim: AnimatedVisibilityScope, modifier: Modifier) {
    val lines = remember(r) { RouteNames.lines(r) }
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            r.number,
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier
                .width(88.dp)
                .sharedElement(rememberSharedContentState("num-${r.number}"), anim)
        )
        Column(
            Modifier
                .weight(1f)
                .sharedElement(rememberSharedContentState("dir-${r.number}"), anim),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            for (l in lines) FitText(l)
        }
    }
}

/** Одна строка крупным шрифтом; если не влезает в ширину, шрифт уменьшается до минимума. */
@Composable
fun FitText(text: String, maxSp: Float = 22f, minSp: Float = 12f) {
    var size by remember(text) { mutableFloatStateOf(maxSp) }
    Text(
        text,
        style = MaterialTheme.typography.titleLarge,
        fontSize = size.sp,
        textAlign = TextAlign.Center,
        maxLines = 1,
        softWrap = false,
        onTextLayout = { if (it.didOverflowWidth && size > minSp) size = (size - 1f).coerceAtLeast(minSp) }
    )
}

@Composable
fun StatusLine(ui: UiState) {
    val fmt = remember { DateTimeFormatter.ofPattern("HH:mm, dd.MM") }
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        if (ui.schedule == null) {
            Text("Данных нет. Нажмите «Обновить» при подключении к Wi-Fi.")
        } else {
            val at = Instant.ofEpochMilli(ui.updatedMs).atZone(MSK).format(fmt)
            Text("Обновлено: $at", style = MaterialTheme.typography.bodyMedium)
            if (System.currentTimeMillis() - ui.updatedMs > 48L * 3600 * 1000) {
                Text("Данные старше 2 суток", color = MaterialTheme.colorScheme.error)
            }
        }
        ui.error?.let {
            Text(
                "Последнее обновление не удалось: $it",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
