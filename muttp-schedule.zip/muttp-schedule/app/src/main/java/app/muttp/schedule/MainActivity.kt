package app.muttp.schedule

import android.app.Application
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class UiState(
    val schedule: Schedule? = null,
    val updatedMs: Long = 0L,
    val error: String? = null,
    val busy: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var ui by mutableStateOf(UiState())
        private set

    private val ctx: Application get() = getApplication()

    init {
        viewModelScope.launch {
            val s = withContext(Dispatchers.IO) { Repo.load(ctx) }
            ui = UiState(s, Repo.updatedMs(ctx), Repo.lastError(ctx))
            // нет данных или они старше 20 часов: пробуем обновить при открытии
            if (s == null || Repo.isStale(ctx)) refresh()
        }
    }

    fun refresh() {
        if (ui.busy) return
        viewModelScope.launch {
            ui = UiState(ui.schedule, ui.updatedMs, ui.error, busy = true)
            withContext(Dispatchers.IO) { Repo.update(ctx) }
            val s = withContext(Dispatchers.IO) { Repo.load(ctx) }
            ui = UiState(s, Repo.updatedMs(ctx), Repo.lastError(ctx))
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { ScheduleScreen() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun isWeekendToday(): Boolean {
    val d = ZonedDateTime.now(MSK).dayOfWeek
    return d == DayOfWeek.SATURDAY || d == DayOfWeek.SUNDAY
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(vm: MainViewModel = viewModel()) {
    val ui = vm.ui
    var tab by rememberSaveable { mutableIntStateOf(if (isWeekendToday()) 1 else 0) }
    var expanded by rememberSaveable { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Расписание автобусов") },
                actions = {
                    TextButton(onClick = { vm.refresh() }, enabled = !ui.busy) { Text("Обновить") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (ui.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            StatusLine(ui)
            TabRow(selectedTabIndex = tab) {
                Tab(
                    selected = tab == 0,
                    onClick = { tab = 0; expanded = null; scope.launch { listState.scrollToItem(0) } },
                    text = { Text("Будни") }
                )
                Tab(
                    selected = tab == 1,
                    onClick = { tab = 1; expanded = null; scope.launch { listState.scrollToItem(0) } },
                    text = { Text("Выходные") }
                )
            }
            val routes = ui.schedule?.let { if (tab == 0) it.weekday else it.weekend }.orEmpty()
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(routes) { index, r ->
                    RouteTile(
                        r = r,
                        expanded = expanded == r.number,
                        onClick = {
                            val open = expanded != r.number
                            expanded = if (open) r.number else null
                            // открытая плитка уезжает наверх экрана
                            if (open) scope.launch { listState.animateScrollToItem(index) }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StatusLine(ui: UiState) {
    val fmt = remember { DateTimeFormatter.ofPattern("HH:mm, dd.MM") }
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        if (ui.schedule == null) {
            Text("Данных нет. Нажмите «Обновить» при подключении к Wi-Fi.")
        } else {
            val at = Instant.ofEpochMilli(ui.updatedMs).atZone(MSK).format(fmt)
            Text("Обновлено: $at", style = MaterialTheme.typography.bodyMedium)
            if (System.currentTimeMillis() - ui.updatedMs > 48L * 3600 * 1000) {
                Text("Данные старше 2 суток", color = MaterialTheme.colorScheme.error)
            }
        }
        ui.error?.let {
            Text(
                "Последнее обновление не удалось: $it",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RouteTile(r: Route, expanded: Boolean, onClick: () -> Unit) {
    val lines = remember(r) { RouteNames.lines(r) }
    Card(Modifier.fillMaxWidth()) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onClick)
                    .padding(horizontal = 16.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    r.number,
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.width(88.dp)
                )
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    for (l in lines) {
                        Text(l, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                    }
                }
            }
            AnimatedVisibility(visible = expanded) {
                Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                    HorizontalDivider()
                    for (s in r.stops) {
                        if (s.times.isEmpty()) continue
                        Spacer(Modifier.height(12.dp))
                        Text(
                            s.name,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            for (d in s.times) Text(d.label(), fontFamily = FontFamily.Monospace)
                        }
                    }
                    for (n in r.notes) {
                        Spacer(Modifier.height(8.dp))
                        Text("* $n", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
