@file:OptIn(
    ExperimentalSharedTransitionApi::class,
    ExperimentalLayoutApi::class,
    ExperimentalMaterial3Api::class
)

package app.muttp.schedule

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class UiState(
    val schedule: Schedule? = null,
    val updatedMs: Long = 0L,
    val error: String? = null,
    val tram: Schedule? = null,
    val tramUpdatedMs: Long = 0L,
    val tramError: String? = null,
    val trolley: Schedule? = null,
    val trolleyUpdatedMs: Long = 0L,
    val trolleyError: String? = null,
    val busy: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var ui by mutableStateOf(UiState())
        private set

    private val ctx: Application get() = getApplication()

    private fun load(): UiState = UiState(
        schedule = Repo.load(ctx),
        updatedMs = Repo.updatedMs(ctx),
        error = Repo.lastError(ctx),
        tram = Repo.loadTram(ctx),
        tramUpdatedMs = Repo.tramUpdatedMs(ctx),
        tramError = Repo.tramLastError(ctx),
        trolley = Repo.loadTrolley(ctx),
        trolleyUpdatedMs = Repo.trolleyUpdatedMs(ctx),
        trolleyError = Repo.trolleyLastError(ctx)
    )

    init {
        viewModelScope.launch {
            ui = withContext(Dispatchers.IO) { load() }
            // нет данных или они старше 20 часов: пробуем обновить при открытии
            if (ui.schedule == null || ui.tram == null || ui.trolley == null || Repo.isStale(ctx)) refresh()
        }
    }

    fun refresh() {
        if (ui.busy) return
        viewModelScope.launch {
            ui = UiState(
                ui.schedule, ui.updatedMs, ui.error,
                ui.tram, ui.tramUpdatedMs, ui.tramError,
                ui.trolley, ui.trolleyUpdatedMs, ui.trolleyError,
                busy = true
            )
            withContext(Dispatchers.IO) { Repo.update(ctx) }
            ui = withContext(Dispatchers.IO) { load() }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppRoot() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

fun isWeekendToday(): Boolean {
    val d = ZonedDateTime.now(MSK).dayOfWeek
    return d == DayOfWeek.SATURDAY || d == DayOfWeek.SUNDAY
}

/** Положение в приложении: раздел (null = главный экран) и открытый маршрут внутри «Автобусов». */
data class Nav(val section: String?, val route: String?)

/**
 * Экраны: главный (4 раздела), список автобусных маршрутов, окно маршрута, заглушки.
 * Номер и направление «переезжают» с плитки в шапку окна маршрута (shared element).
 */
@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val ui = vm.ui
    var tab by rememberSaveable { mutableIntStateOf(if (isWeekendToday()) 1 else 0) }
    var section by rememberSaveable { mutableStateOf<String?>(null) }
    var openNumber by rememberSaveable { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val miniListState = rememberLazyListState()
    val miniSchedule = remember { Minibus.build() }
    val tramListState = rememberLazyListState()
    val trolleyListState = rememberLazyListState()
    val tramStub = remember { TramBuilder.stub() }
    val routes = ui.schedule?.let { if (tab == 0) it.weekday else it.weekend }.orEmpty()
    val miniRoutes = if (tab == 0) miniSchedule.weekday else miniSchedule.weekend
    val tramRoutes = (ui.tram?.let { if (tab == 0) it.weekday else it.weekend }.orEmpty() + tramStub)
        .sortedBy { it.number }
    val trolleyRoutes = ui.trolley?.let { if (tab == 0) it.weekday else it.weekend }.orEmpty()

    BackHandler(enabled = section != null || openNumber != null) {
        if (openNumber != null) openNumber = null else section = null
    }

    SharedTransitionLayout {
        AnimatedContent(
            targetState = Nav(section, openNumber),
            transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
            label = "screen"
        ) { nav ->
            when (nav.section) {
                null -> HomeScreen(onOpen = { section = it }, onSettings = { section = "settings" })
                "settings" -> SettingsScreen(onBack = { section = null })
                "bus", "minibus", "tram", "trolley" -> {
                    val kind = nav.section
                    val sectionRoutes = when (kind) {
                        "bus" -> routes
                        "minibus" -> miniRoutes
                        "tram" -> tramRoutes
                        else -> trolleyRoutes
                    }
                    val route = if (nav.route == null) null else sectionRoutes.firstOrNull { it.number == nav.route }
                    if (route == null) {
                        RouteListScreen(
                            anim = this@AnimatedContent,
                            title = when (kind) {
                                "bus" -> "Автобусы"
                                "minibus" -> "Маршрутки"
                                "tram" -> "Трамваи"
                                else -> "Троллейбусы"
                            },
                            showUpdate = kind != "minibus",
                            busy = ui.busy,
                            error = when (kind) {
                                "tram" -> ui.tramError
                                "trolley" -> ui.trolleyError
                                else -> ui.error
                            },
                            updatedMs = when (kind) {
                                "tram" -> ui.tramUpdatedMs
                                "trolley" -> ui.trolleyUpdatedMs
                                else -> ui.updatedMs
                            },
                            hasData = when (kind) {
                                "tram" -> ui.tram != null
                                "trolley" -> ui.trolley != null
                                else -> ui.schedule != null
                            },
                            routes = sectionRoutes,
                            tab = tab,
                            listState = when (kind) {
                                "bus" -> listState
                                "minibus" -> miniListState
                                "tram" -> tramListState
                                else -> trolleyListState
                            },
                            onTab = { tab = it },
                            onRefresh = { vm.refresh() },
                            onOpen = { openNumber = it },
                            onBack = { section = null; openNumber = null }
                        )
                    } else {
                        RouteDetailScreen(
                            anim = this@AnimatedContent,
                            r = route,
                            onBack = { openNumber = null }
                        )
                    }
                }
                else -> EmptyScreen(title = sectionTitle(nav.section), onBack = { section = null })
            }
        }
    }
}

private fun sectionTitle(section: String?): String = when (section) {
    "minibus" -> "Маршрутки"
    "tram" -> "Трамваи"
    "trolley" -> "Троллейбусы"
    else -> ""
}

/** Главный экран: четыре раздела. Логотипы позже. */
@Composable
fun HomeScreen(onOpen: (String) -> Unit, onSettings: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Расписание транспорта") },
                navigationIcon = {
                    IconButton(onClick = onSettings) {
                        Text("☰", style = MaterialTheme.typography.headlineSmall)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // плитки занимают всё, что осталось над блоком контактов
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeTile("Автобусы", Color(0xFFFFEFB0), Modifier.weight(1f)) { onOpen("bus") }
                HomeTile("Маршрутки", Color(0xFFCBD8E6), Modifier.weight(1f)) { onOpen("minibus") }
                HomeTile("Трамваи", Color(0xFFF4C9C9), Modifier.weight(1f)) { onOpen("tram") }
                HomeTile("Троллейбусы", Color(0xFFCDEBC6), Modifier.weight(1f)) { onOpen("trolley") }
            }
            ContactsCard()
        }
    }
}

/** Страница настроек. Пока пустая. */
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Настройки") },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize())
    }
}

/** Кнопка-ссылка внутри блока контактов. */
@Composable
fun ContactButton(text: String, container: Color, content: Color, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content)
    ) {
        Text(text, textDecoration = TextDecoration.Underline)
    }
}

/**
 * Блок внизу главного экрана: адреса, телефоны диспетчера, сайт. Данные в Contacts.kt.
 * Каждый пункт на отдельной плашке чуть темнее самой панели. Телефон открывает набор номера
 * (без звонка), сайт открывается в браузере.
 */
@Composable
fun ContactsCard() {
    val ctx = LocalContext.current
    val panel = MaterialTheme.colorScheme.surfaceVariant
    val darker = lerp(panel, Color.Black, 0.10f)
    val textColor = MaterialTheme.colorScheme.onSurfaceVariant
    val open: (Intent) -> Unit = { intent ->
        try {
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            // нет подходящего приложения, ничего не делаем
        }
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = panel)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Адрес:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (a in Contacts.addresses) {
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = darker)) {
                        Text(
                            a,
                            Modifier.fillMaxWidth().padding(10.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
            Text("Центральный диспетчер", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            for (p in Contacts.phones) {
                ContactButton("${p.label} ${p.display}", darker, textColor, Modifier.fillMaxWidth()) {
                    open(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.dial}")))
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Сайт:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                ContactButton(Contacts.SITE, darker, textColor, Modifier.weight(1f)) {
                    open(Intent(Intent.ACTION_VIEW, Uri.parse("https://" + Contacts.SITE)))
                }
            }
        }
    }
}

@Composable
fun HomeTile(title: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color, contentColor = Color(0xFF2B2B2B))
    ) {
        Box(
            Modifier.fillMaxSize().clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun EmptyScreen(title: String, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Пока пусто", style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
fun SharedTransitionScope.RouteListScreen(
    anim: AnimatedVisibilityScope,
    title: String,
    showUpdate: Boolean,
    busy: Boolean,
    error: String?,
    updatedMs: Long,
    hasData: Boolean,
    routes: List<Route>,
    tab: Int,
    listState: LazyListState,
    onTab: (Int) -> Unit,
    onRefresh: () -> Unit,
    onOpen: (String) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (showUpdate) {
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                UpdateBar(busy, error, updatedMs, hasData, onRefresh)
            }
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { onTab(0) }, text = { Text("Будни") })
                Tab(selected = tab == 1, onClick = { onTab(1) }, text = { Text("Выходные") })
            }
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(routes) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        RouteHeader(r, anim, Modifier.clickable { onOpen(r.number) })
                    }
                }
            }
        }
    }
}

/** Окно маршрута. Сюда позже добавится дополнительная информация о маршруте. */
@Composable
fun SharedTransitionScope.RouteDetailScreen(
    anim: AnimatedVisibilityScope,
    r: Route,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = { TextButton(onClick = onBack) { Text("← Назад") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                RouteHeader(r, anim, Modifier)
            }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                if (r.info.isNotEmpty()) {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            r.info.forEachIndexed { i, line ->
                                if (i == 0) {
                                    Text(line, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                } else {
                                    Text(line, style = MaterialTheme.typography.bodyLarge)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                // плитки направлений (троллейбусы): чуть темнее фона, расписания раздельно по сторонам
                for (g in r.groups) {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(g.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            for (s in g.stops) {
                                Spacer(Modifier.height(10.dp))
                                StopBlock(s)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                // Если у маршрута одна сноска и в расписании есть рейсы со звёздочкой,
                // сноска стоит под тем списком, где эти звёздочки. Иначе сноски внизу.
                val single = r.notes.distinct().singleOrNull()
                val notesUnderStops = single != null && r.stops.any { st -> st.times.any { it.starred } }
                val lastStarred = r.stops.lastOrNull { st -> st.times.any { it.starred } }
                for (s in r.stops) {
                    if (s.times.isEmpty()) continue
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            StopBlock(s)
                            if (notesUnderStops && s.times.any { it.starred } && (!r.noteOnce || s === lastStarred)) {
                                Text("* $single", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                if (!notesUnderStops) {
                    for (n in r.notes.distinct()) {
                        Text("* $n", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(4.dp))
                    }
                }
                for (m in r.remarks) {
                    Text(m, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(4.dp))
                }
                // сюда позже: дополнительная информация о маршруте
            }
        }
    }
}

/** Остановка отправления: название, уточнение, времена и сноски. */
@Composable
fun StopBlock(s: Stop) {
    Text(
        s.name,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary
    )
    s.sub?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        for (d in s.times) Text(d.label(), fontFamily = FontFamily.Monospace)
    }
    for (f in s.footnotes) Text(f, style = MaterialTheme.typography.bodySmall)
}

/** Номер слева, направление справа по центру. Одинаковый вид в списке и в окне маршрута. */
@Composable
fun SharedTransitionScope.RouteHeader(r: Route, anim: AnimatedVisibilityScope, modifier: Modifier) {
    val lines = remember(r) { RouteNames.lines(r) }
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            r.number,
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier
                .width(88.dp)
                .sharedElement(rememberSharedContentState("num-${r.number}"), anim)
        )
        Column(
            Modifier
                .weight(1f)
                .sharedElement(rememberSharedContentState("dir-${r.number}"), anim),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            for (l in lines) FitText(l)
        }
    }
}

/** Одна строка крупным шрифтом; если не влезает в ширину, шрифт уменьшается до минимума. */
@Composable
fun FitText(text: String, maxSp: Float = 22f, minSp: Float = 10f) {
    var size by remember(text) { mutableFloatStateOf(maxSp) }
    Text(
        text,
        style = MaterialTheme.typography.titleLarge,
        fontSize = size.sp,
        textAlign = TextAlign.Center,
        maxLines = 1,
        softWrap = false,
        onTextLayout = { if (it.didOverflowWidth && size > minSp) size = (size - 1f).coerceAtLeast(minSp) }
    )
}

/**
 * Кнопка обновления с временем последнего обновления.
 * Свежие данные (меньше суток): цвет темы. Старше суток или данных нет: красная.
 */
@Composable
fun UpdateBar(busy: Boolean, error: String?, updatedMs: Long, hasData: Boolean, onRefresh: () -> Unit) {
    val fmt = remember { DateTimeFormatter.ofPattern("H:mm dd.MM") }
    val stale = !hasData || System.currentTimeMillis() - updatedMs > 24L * 3600 * 1000
    val label = when {
        busy -> "Обновление…"
        !hasData -> "Обновить"
        else -> "Обновлено " + Instant.ofEpochMilli(updatedMs).atZone(MSK).format(fmt)
    }
    val colors = if (stale) {
        ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error,
            contentColor = MaterialTheme.colorScheme.onError
        )
    } else {
        ButtonDefaults.buttonColors()
    }
    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
        Button(
            onClick = onRefresh,
            enabled = !busy,
            colors = colors,
            modifier = Modifier.fillMaxWidth()
        ) { Text(label) }
        error?.let {
            Text(
                if (it == Repo.ERR_NET) it else "Не удалось обновить: $it",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
