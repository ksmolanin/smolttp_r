package app.muttp.schedule

import android.content.Context

/**
 * Промежуточные остановки, которые пользователь сам добавил на главный экран маршрута (кнопка
 * «три полоски» → галочка у остановки). Хранятся по маршруту и направлению («f»/«r»), ключ —
 * "<номер маршрута>:<f|r>" -> список названий остановок, самая новая последней.
 *
 * Лимит — не больше MAX_PER_DIRECTION штук на направление (п. 1 задания: максимум 2 промежуточных
 * плюс начальная/конечная = 3 плитки на направление).
 */
object CustomStops {
    const val MAX_PER_DIRECTION = 2

    private fun prefs(c: Context) = c.getSharedPreferences("custom_stops", Context.MODE_PRIVATE)
    private fun key(routeNumber: String, forward: Boolean) = "$routeNumber:" + if (forward) "f" else "r"

    fun load(c: Context, routeNumber: String, forward: Boolean): List<String> =
        prefs(c).getString(key(routeNumber, forward), "").orEmpty().split("\n").filter { it.isNotEmpty() }

    fun save(c: Context, routeNumber: String, forward: Boolean, list: List<String>) {
        prefs(c).edit().putString(key(routeNumber, forward), list.joinToString("\n")).apply()
    }

    /** true, если получилось добавить (внутри лимита); false — на этом направлении уже 2 добавленных. */
    fun add(c: Context, routeNumber: String, forward: Boolean, stopName: String): Boolean {
        val cur = load(c, routeNumber, forward)
        if (stopName in cur) return true
        if (cur.size >= MAX_PER_DIRECTION) return false
        save(c, routeNumber, forward, cur + stopName)
        return true
    }

    fun remove(c: Context, routeNumber: String, forward: Boolean, stopName: String) {
        save(c, routeNumber, forward, load(c, routeNumber, forward) - stopName)
    }
}
