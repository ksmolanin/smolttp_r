package app.muttp.schedule

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Данные о времени между остановками (assets/transit_registry.json), подготовленные автором
 * отдельно от сайта. Отсюда приложение берёт время для кастомных промежуточных остановок,
 * которые пользователь сам добавляет в маршрут (см. CustomStops.kt).
 *
 * Формат файла: список остановок (stops) и для каждого маршрута — «вперёд» и «назад»
 * (forward/reverse), каждое — список id остановок и минут между соседними из них.
 */
object TransitRegistry {
    class Candidate(val name: String, val minutes: Int, val starredOnly: Boolean = false)

    private class Direction(val originId: Int, val names: List<String>, val cumMinutes: List<Int>)
    private class RouteEntry(val forward: Direction, val reverse: Direction)

    private var stopNames: List<String> = emptyList()
    private var routes: Map<String, RouteEntry> = emptyMap()
    private var loaded = false

    /** Разово читает assets/transit_registry.json. Если файла нет или он битый — кастомные
     * остановки просто не предлагаются, приложение не падает. */
    fun ensureLoaded(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val text = ctx.assets.open("transit_registry.json").bufferedReader(Charsets.UTF_8).readText()
            val root = JSONObject(text)
            val stopsArr = root.getJSONArray("stops")
            stopNames = List(stopsArr.length()) { stopsArr.getString(it) }

            fun direction(arr: JSONArray): Direction {
                val idsArr = arr.getJSONArray(0)
                val minArr = arr.getJSONArray(1)
                val ids = IntArray(idsArr.length()) { idsArr.getInt(it) }
                var cum = 0
                var broken = false
                val cums = ArrayList<Int>(ids.size)
                for (i in ids.indices) {
                    if (broken || minArr.isNull(i)) {
                        broken = true
                        cums.add(-1) // время неизвестно (на сайте был пропуск в этом месте)
                    } else {
                        cum += minArr.getInt(i)
                        cums.add(cum)
                    }
                }
                return Direction(ids[0], ids.map { stopNames.getOrElse(it) { "" } }, cums)
            }

            val routesObj = root.getJSONObject("routes")
            val map = HashMap<String, RouteEntry>()
            for (key in routesObj.keys()) {
                val pair = routesObj.getJSONArray(key)
                map[key] = RouteEntry(direction(pair.getJSONArray(0)), direction(pair.getJSONArray(1)))
            }
            routes = map
        } catch (e: Exception) {
            routes = emptyMap()
        }
    }

    /**
     * Остановки-кандидаты для блока маршрута (пропускает первую — она и есть сам блок).
     * dirKey: "forward" или "reverse" — какое направление реестра соответствует этому блоку.
     * variantOf: ключ варианта в реестре (например «7 с заездом в Пасово»), если есть — его
     * дополнительные остановки добавляются в список с пометкой starredOnly.
     */
    fun candidates(routeKey: String, dirKey: String, variantOf: String? = null): List<Candidate> {
        val entry = routes[routeKey] ?: return emptyList()
        val dir = if (dirKey == "forward") entry.forward else entry.reverse
        val base = dir.names.indices.drop(1).mapNotNull { i ->
            if (dir.cumMinutes[i] < 0) null else Candidate(dir.names[i], dir.cumMinutes[i])
        }
        val baseNames = base.map { it.name }.toSet()
        val variant = variantOf?.let { routes[it] }
        val extra = if (variant != null) {
            val vdir = if (dirKey == "forward") variant.forward else variant.reverse
            vdir.names.indices.drop(1).mapNotNull { i ->
                val name = vdir.names[i]
                if (name in baseNames || vdir.cumMinutes[i] < 0) null
                else Candidate(name, vdir.cumMinutes[i], starredOnly = true)
            }
        } else emptyList()
        return base + extra
    }
}
