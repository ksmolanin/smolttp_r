package app.muttp.schedule

/**
 * Ручные правки поверх данных сайта (подписи, сноски, добавленные рейсы).
 * Применяются после Merger, только для показа. Сайт при этом не меняется.
 * Если сайт поменяет названия остановок, правка просто не найдёт остановку и ничего не сделает.
 */
object Tweaks {
    private val nonWord = Regex("""[^\p{L}\p{N}]""")
    private fun norm(s: String) = nonWord.replace(s.lowercase(), "")

    fun apply(s: Schedule): Schedule {
        for (r in s.weekday) tweak(r, weekend = false)
        for (r in s.weekend) tweak(r, weekend = true)
        for (r in s.weekday + s.weekend) fixAbbrev(r)
        return s
    }

    private fun fixAbbrev(r: Route) {
        for (st in r.stops) {
            st.name = Abbrev.fix(st.name)
            st.sub = st.sub?.let { Abbrev.fix(it) }
        }
        for (i in r.notes.indices) r.notes[i] = Official.note(Abbrev.fix(r.notes[i]))
    }

    private fun starFirst(st: Stop?, count: Int) {
        if (st == null) return
        for (i in 0 until minOf(count, st.times.size)) {
            val d = st.times[i]
            st.times[i] = Dep(d.hour, d.minute, true)
        }
    }

    private fun starTime(st: Stop, hour: Int, minute: Int) {
        for (i in st.times.indices) {
            val d = st.times[i]
            if (d.hour == hour && d.minute == minute) st.times[i] = Dep(hour, minute, true)
        }
    }

    private fun find(r: Route, name: String): Stop? =
        r.stops.firstOrNull { norm(it.name) == norm(name) }

    private fun sortTimes(st: Stop) = st.times.sortBy { it.hour * 60 + it.minute }

    private fun renameNote(r: Route, from: String, to: String) {
        for (i in r.notes.indices) if (norm(r.notes[i]) == norm(from)) r.notes[i] = to
    }

    private fun tweak(r: Route, weekend: Boolean) {
        when (r.number) {
            "3" -> {
                find(r, "пл.Победы")?.name = "пл.Победы (КБСМП)"
            }
            "7" -> {
                r.noteOnce = true
            }
            "11" -> {
                find(r, "пл. Победы")?.name = "пл. Победы (Аптека)"
            }
            "22" -> {
                val avtoz = find(r, "Автозаводская")
                val school = r.stops.firstOrNull { norm(it.name).startsWith("37") }
                if (!weekend) {
                    // ранние рейсы через промзону (только будни)
                    starFirst(school, 5)
                    starFirst(avtoz, 6)
                    r.notes.add("через промзону")
                    r.noteOnce = true
                }
                avtoz?.name = "ул. Автозаводская"
                school?.name = "8-й мкрн. Киселевка"
            }
            "24" -> {
                // в выходные маршрут называется 24в
                if (weekend) r.number = "24в"
                r.noteOnce = true
            }
            "25" -> {
                find(r, "8-й Микрорайон")?.name = "8-й мкрн. Киселевка"
            }
            "30" -> {
                find(r, "Желябова")?.name = "пл. Желябова"
                find(r, "мкр.Гнездово")?.name = "мкрн. Гнёздово (ул. Щорса)"
            }
            "9" -> {
                find(r, "пл. Победы-Садки")?.let {
                    it.name = "пл.Победы (КБСМП)"
                    it.sub = "в направлении Садки"
                }
            }
            "8" -> {
                renameNote(r, "в гараж", "до пл. Победы")
            }
            "14" -> {
                // рейса 19:25 на сайте нет, добавлен вручную (только будни)
                if (!weekend) {
                    find(r, "Шейновка")?.let {
                        starTime(it, 13, 50)
                        it.times.add(Dep(19, 25, true))
                        sortTimes(it)
                    }
                    r.notes.add("до пл. Победы")
                }
            }
            "33" -> {
                var prev = ""
                for (st in r.stops) {
                    if (norm(st.name).contains("киевская")) {
                        st.name = "ул. 2я Киевская"
                        st.sub = if (norm(prev).startsWith("жд")) {
                            "в направлении Вишенки"
                        } else {
                            "в направлении Ж/д вокзал"
                        }
                    }
                    prev = st.name
                }
            }
            "34" -> {
                // три последних рейса с Королевки (только будни)
                if (!weekend) {
                    find(r, "Королевка")?.let { st ->
                        val n = st.times.size
                        for (i in maxOf(0, n - 3) until n) {
                            val d = st.times[i]
                            st.times[i] = Dep(d.hour, d.minute, true)
                        }
                    }
                    r.notes.add("до школы №37")
                }
            }
            "50" -> {
                r.notes.clear()
                r.notes.add("до пл. Желябова")
                val subs = listOf("Велижская — Вишенки", "Желябова — Вишенки", "Вишенки — Велижская")
                if (r.stops.size == subs.size) {
                    r.stops.forEachIndexed { i, st -> st.sub = subs[i] }
                }
            }
            "53" -> {
                // блок «Вишенки»: только подпись и время, без звёздочки
                find(r, "Вишенки")?.let { st ->
                    st.sub = "в направлении пл. Желябова"
                    for (i in st.times.indices) {
                        val d = st.times[i]
                        st.times[i] = Dep(d.hour, d.minute, false)
                    }
                }
            }
            "54" -> {
                find(r, "Школа (Кр.Бор)")?.name = "Школа (Красный Бор)"
            }
        }
    }
}

/**
 * Единый вежливый стиль сносок: «* Рейс следует до пл. Победы».
 * Сноски сайта и добавленные вручную приводятся к одному виду.
 */
object Official {
    private val starts = listOf("до ", "только до", "через ", "с заездом", "без заезда", "в ")

    fun note(s: String): String {
        val t = s.trim().trimEnd('.', ';')
        val lower = t.lowercase()
        val text = when {
            lower.startsWith("рейс") -> t.replaceFirstChar { it.uppercase() }
            starts.any { lower.startsWith(it) } -> "Рейс следует " + t.replaceFirstChar { it.lowercase() }
            else -> t.replaceFirstChar { it.uppercase() }
        }
        return text.replace("продлен ", "продлён ")
    }
}
