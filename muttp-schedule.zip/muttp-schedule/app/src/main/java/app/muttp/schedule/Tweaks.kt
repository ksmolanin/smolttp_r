package app.muttp.schedule

/**
 * Ручные правки поверх данных сайта (подписи, сноски, добавленные рейсы).
 * Применяются после Merger, только для показа. Сайт при этом не меняется.
 * Если сайт поменяет названия остановок, правка просто не найдёт остановку и ничего не сделает.
 */
object Tweaks {
    private val nonWord = Regex("""[^\p{L}\p{N}]""")
    private fun norm(s: String) = nonWord.replace(s.lowercase(), "")

    fun apply(s: Schedule): Schedule {
        for (r in s.weekday) tweak(r, weekend = false)
        for (r in s.weekend) tweak(r, weekend = true)
        for (r in s.weekday + s.weekend) fixAbbrev(r)
        for (r in s.weekday + s.weekend) Directions.apply(r)
        return s
    }

    private fun fixAbbrev(r: Route) {
        for (st in r.stops) {
            st.name = Abbrev.fix(st.name)
            st.sub = st.sub?.let { Abbrev.fix(it) }
        }
        for (i in r.notes.indices) r.notes[i] = Official.note(Abbrev.fix(r.notes[i]))
    }

    /** Помечает первые count времён буквой (например «з» у 22: рейс через промзону). */
    private fun markFirst(st: Stop?, count: Int, mark: String) {
        if (st == null) return
        for (i in 0 until minOf(count, st.times.size)) {
            val d = st.times[i]
            st.times[i] = Dep(d.hour, d.minute, false, mark)
        }
    }

    private fun starFirst(st: Stop?, count: Int) {
        if (st == null) return
        for (i in 0 until minOf(count, st.times.size)) {
            val d = st.times[i]
            st.times[i] = Dep(d.hour, d.minute, true)
        }
    }

    private fun starTime(st: Stop, hour: Int, minute: Int) {
        for (i in st.times.indices) {
            val d = st.times[i]
            if (d.hour == hour && d.minute == minute) st.times[i] = Dep(hour, minute, true)
        }
    }

    private fun find(r: Route, name: String): Stop? =
        r.stops.firstOrNull { norm(it.name) == norm(name) }

    private fun sortTimes(st: Stop) = st.times.sortBy { it.hour * 60 + it.minute }

    private fun renameNote(r: Route, from: String, to: String) {
        for (i in r.notes.indices) if (norm(r.notes[i]) == norm(from)) r.notes[i] = to
    }

    private fun tweak(r: Route, weekend: Boolean) {
        when (r.number) {
            "3" -> {
                find(r, "пл.Победы")?.name = "пл.Победы (КБСМП)"
            }
            "7" -> {
                r.noteOnce = true
            }
            "11" -> {
                find(r, "пл. Победы")?.name = "пл. Победы (Аптека)"
            }
            "22" -> {
                val avtoz = find(r, "Автозаводская")
                val school = r.stops.firstOrNull { norm(it.name).startsWith("37") }
                avtoz?.name = "ул. Автозаводская"
                school?.name = "8-й мкрн. Киселевка"
                r.noteOnce = true
            }
            "24" -> {
                // в выходные маршрут называется 24в
                if (weekend) r.number = "24в"
                r.noteOnce = true
            }
            "25" -> {
                find(r, "8-й Микрорайон")?.name = "8-й мкрн. Киселевка"
            }
            "30" -> {
                find(r, "Желябова")?.name = "пл. Желябова"
                find(r, "мкр.Гнездово")?.name = "мкрн. Гнёздово (ул. Щорса)"
            }
            "9" -> {
                find(r, "пл. Победы-Садки")?.let {
                    it.name = "пл.Победы (КБСМП)"
                    it.sub = "в направлении Садки"
                }
            }
            "33" -> {
                var prev = ""
                for (st in r.stops) {
                    if (norm(st.name).contains("киевская")) {
                        st.name = "ул. 2я Киевская"
                        st.sub = if (norm(prev).startsWith("жд")) {
                            "в направлении Вишенки"
                        } else {
                            "в направлении Ж/д вокзал"
                        }
                    }
                    prev = st.name
                }
            }
            "53" -> {
                // блок «Вишенки»: только подпись и время, без звёздочки
                find(r, "Вишенки")?.let { st ->
                    st.sub = "в направлении пл. Желябова"
                    for (i in st.times.indices) {
                        val d = st.times[i]
                        st.times[i] = Dep(d.hour, d.minute, false, "", 0, d.annot)
                    }
                }
            }
            "54" -> {
                find(r, "Школа (Кр.Бор)")?.name = "Школа (Красный Бор)"
            }
        }
    }
}

/**
 * Единый вежливый стиль сносок: «* Рейс следует до пл. Победы».
 * Сноски сайта и добавленные вручную приводятся к одному виду.
 */
object Official {
    private val starts = listOf("до ", "только до", "через ", "с заездом", "без заезда", "в ")

    private val siteStar = Regex("""^Рейсы,? отмеченные звездочкой,? следуют (.*)$""", RegexOption.IGNORE_CASE)

    fun note(s: String): String {
        val raw = s.trim().trimEnd('.', ';')
        val t = siteStar.find(raw)?.let { "Рейс следует " + it.groupValues[1] } ?: raw
        val lower = t.lowercase()
        val text = when {
            lower.startsWith("рейс") -> t.replaceFirstChar { it.uppercase() }
            starts.any { lower.startsWith(it) } -> "Рейс следует " + t.replaceFirstChar { it.lowercase() }
            else -> t.replaceFirstChar { it.uppercase() }
        }
        return text.replace("продлен ", "продлён ")
    }
}

/**
 * Автобусы: плоский список остановок отправления, как на сайте. Конечные подписаны названием,
 * промежуточные в виде «откуда - куда» (вместо прежнего «в направлении …»).
 * Подписи заданы вручную по номеру маршрута и номеру блока на странице сайта.
 */
object Directions {
    private fun labels(r: Route): Map<Int, String> = when (r.number) {
        "9" -> mapOf(1 to "Садки - Колхозный переулок")
        "12" -> mapOf(1 to "Красный Бор - Пронино", 3 to "Красный Бор - пл. Желябова")
        "33" -> if (r.stops.size == 4) {
            mapOf(1 to "ул. 2я Киевская - Вишенки", 3 to "ул. 2я Киевская - Ж/д вокзал")
        } else {
            mapOf(2 to "ул. 2я Киевская - Ж/д вокзал")
        }
        "50" -> mapOf(1 to "пл. Желябова - Вишенки")
        "53" -> mapOf(2 to "Вишенки - пл. Желябова")
        "54" -> mapOf(1 to "Школа (Красный Бор) - пос. Торфопредприятие", 2 to "пос. Торфопредприятие")
        else -> emptyMap()
    }

    /**
     * Промежуточная остановка: время = время отправления из блока source + offset минут.
     * Вставляется в плоский список сразу после блока after (индексы по списку сайта).
     */
    private class Add(val source: Int, val offset: Int, val label: String, val after: Int)

    private fun additions(r: Route): List<Add> = when (r.number) {
        "3" -> listOf(Add(0, 9, "Колхозная пл. - Колодня", 0))
        "7" -> listOf(Add(0, 9, "Колхозная пл. - Корохоткино", 0))
        "9" -> listOf(Add(1, 27, "пл. Победы - Колхозный пер.", 1))
        "11" -> listOf(Add(1, 14, "мкрн. Южный - пл. Победы", 1))
        "14" -> listOf(Add(0, 10, "пл. Победы - Шейновка", 0))
        "19" -> listOf(Add(0, 9, "Колхозная пл. - Спортбаза", 0))
        "33" -> listOf(Add(0, 13, "пл. Победы - Вишенки", 0))
        "22" -> listOf(
            Add(0, 25, "пл. Победы - 8-й мкрн. Киселевка", 0),
            Add(1, 24, "пл. Победы - ул. Автозаводская", 1)
        )
        "31" -> listOf(Add(0, 9, "пл. Победы - пос. Миловидово", 0))
        "31к" -> listOf(Add(0, 9, "пл. Победы - ЖК Загорье", 0))
        "34" -> listOf(Add(0, 20, "Колхозная пл. - 7-й мкрн. Киселевка", 0))
        "50" -> listOf(Add(1, 19, "кт. Современник - Вишенки", 1))
        "53" -> listOf(Add(0, 13, "пл. Победы - Окружная дорога", 0))
        else -> emptyList()
    }

    /** Возвращает: новый блок -> блок, после которого он вставлен. */
    private fun insertIntermediates(r: Route): Map<Stop, Stop> {
        val result = LinkedHashMap<Stop, Stop>()
        val adds = additions(r)
        if (adds.isEmpty()) return result
        val original = r.stops.toList()
        // если структура страницы изменилась, ничего не добавляем
        if (adds.any { it.source >= original.size || it.after >= original.size }) return result
        if (adds.any { original[it.source].times.isEmpty() }) return result
        for (a in adds.sortedByDescending { it.after }) {
            val st = Stop(a.label)
            for (d in original[a.source].times) {
                val total = (d.hour * 60 + d.minute + a.offset) % (24 * 60)
                st.times.add(Dep(total / 60, total % 60, d.starred, d.mark))
            }
            val pos = r.stops.indexOf(original[a.after]) + 1
            r.stops.add(pos, st)
            result[st] = original[a.after]
        }
        return result
    }

    /** Направления: номера блоков страницы сайта (до вставки промежуточных). */
    private fun directions(r: Route, count: Int): List<List<Int>>? = when (r.number) {
        "3", "7", "8", "11", "14", "15", "19", "22", "25", "28", "30", "31", "31к", "34" ->
            listOf(listOf(0), listOf(1))
        "9", "54" -> listOf(listOf(0, 1, 2))
        "12" -> listOf(listOf(0, 1), listOf(2, 3))
        "24" -> listOf(listOf(0), listOf(1, 2))
        "24в" -> listOf(listOf(1), listOf(0, 2))
        "33" -> if (count == 4) listOf(listOf(0, 1), listOf(2, 3)) else listOf(listOf(0), listOf(1, 2))
        "50" -> listOf(listOf(0, 1), listOf(2))
        "53" -> listOf(listOf(0), listOf(1, 2))
        else -> null
    }

    /** Сноска про букву-метку ставится один раз, под последним блоком, где эта метка есть. */
    private fun addMarkLegend(r: Route, mark: String, text: String) {
        val last = r.stops.lastOrNull { st -> st.times.any { it.mark == mark } } ?: return
        last.footnotes.add(text)
    }

    /**
     * Плитка на каждое направление (без заголовка), внутри плашки расписаний.
     * Простые маршруты, где в каждом направлении по одному блоку, остаются плоским списком.
     */
    private fun group(r: Route, original: List<Stop>, added: Map<Stop, Stop>) {
        val dirs = directions(r, original.size) ?: return
        if (dirs.any { d -> d.any { it >= original.size } }) return
        val groups = dirs.map { idxs ->
            val g = Group("")
            for (i in idxs) {
                val st = original[i]
                if (st.times.isEmpty()) continue
                g.stops.add(st)
                for ((n, after) in added) if (after === st) g.stops.add(n)
            }
            g
        }.filter { it.stops.isNotEmpty() }
        if (groups.none { it.stops.size >= 2 }) return
        // сноска со звёздочкой стоит под тем списком, где эти звёздочки
        val flat = groups.flatMap { it.stops }
        val single = r.notes.distinct().singleOrNull()
        val under = single != null && flat.any { st -> st.times.any { it.starred } }
        if (under) {
            val last = flat.lastOrNull { st -> st.times.any { it.starred } }
            for (st in flat) {
                if (st.times.any { it.starred } && (!r.noteOnce || st === last)) st.footnotes.add("* $single")
            }
            r.notes.clear()
        }
        r.groups.addAll(groups)
        r.stops.clear()
    }

    fun apply(r: Route) {
        // подписей «в направлении …» у автобусов больше нет
        for (st in r.stops) st.sub = null
        for ((i, label) in labels(r)) {
            if (i < r.stops.size) r.stops[i].name = label
        }
        val original = r.stops.toList()
        val added = insertIntermediates(r)
        BusMarks.apply(r)
        group(r, original, added)
    }
}

/**
 * Пометки автобусных рейсов только по данным сайта: звёздочки сохраняют своё число («*», «**»),
 * пометки в скобках («в парк», «из депо») получают первое свободное число в этом блоке.
 * Под каждым блоком сноски только для тех пометок, что в нём есть. Если у маршрута noteOnce,
 * сноска стоит один раз, под последним блоком с такой пометкой.
 */
object BusMarks {
    private class Fn(val count: Int, val key: String, val text: String)

    private fun legendText(r: Route, level: Int): String {
        val texts = r.legend[level].orEmpty().distinct().map { Official.note(Abbrev.fix(it)) }
        if (texts.isEmpty()) return "Особый рейс"
        val joined = texts.joinToString("; ")
        // 22з: рейсы через промзону
        return if (r.number == "22" && joined.contains("промзон", ignoreCase = true)) {
            "22з следует через промзону"
        } else {
            joined
        }
    }

    fun apply(r: Route) {
        val perStop = LinkedHashMap<Stop, List<Fn>>()
        val usedLevels = mutableSetOf<Int>()
        for (st in r.stops) {
            if (st.times.isEmpty()) continue
            val levels = st.times.map { it.stars }.filter { it > 0 }.toSortedSet()
            val annots = st.times.map { it.annot }.filter { it.isNotEmpty() }.distinct()
            var next = 1
            fun free(): Int {
                while (next in levels) next++
                return next++
            }
            val annotSym = LinkedHashMap<String, Int>()
            for (a in annots) annotSym[a] = free()
            val fns = mutableListOf<Fn>()
            for (l in levels) {
                usedLevels.add(l)
                fns.add(Fn(l, "L$l", legendText(r, l)))
            }
            for ((a, c) in annotSym) fns.add(Fn(c, "A:$a", "Рейс следует $a"))
            perStop[st] = fns
            for ((i, t) in st.times.withIndex()) {
                val parts = mutableListOf<String>()
                if (t.stars > 0) parts.add("*".repeat(t.stars))
                if (t.annot.isNotEmpty()) parts.add("*".repeat(annotSym[t.annot] ?: 1))
                st.times[i] = Dep(t.hour, t.minute, false, parts.joinToString(","), t.stars, t.annot)
            }
        }
        val lastFor = HashMap<String, Stop>()
        for ((st, fns) in perStop) for (f in fns) lastFor[f.key] = st
        for ((st, fns) in perStop) {
            val keep = fns.filter { !r.noteOnce || lastFor[it.key] === st }
            st.footnotes.addAll(keep.sortedBy { it.count }.map { "*".repeat(it.count) + " " + it.text })
        }
        // расшифровки звёздочек, которых нет ни у одного рейса, остаются внизу обычным текстом
        for (level in r.legend.keys.sorted()) {
            if (level !in usedLevels) r.remarks.add(legendText(r, level))
        }
    }
}
