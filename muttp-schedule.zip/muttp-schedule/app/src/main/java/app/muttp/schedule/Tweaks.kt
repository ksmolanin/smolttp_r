package app.muttp.schedule

/**
 * Ручные правки поверх данных сайта (подписи, сноски, добавленные рейсы).
 * Применяются после Merger, только для показа. Сайт при этом не меняется.
 * Если сайт поменяет названия остановок, правка просто не найдёт остановку и ничего не сделает.
 */
object Tweaks {
    private val nonWord = Regex("""[^\p{L}\p{N}]""")
    private fun norm(s: String) = nonWord.replace(s.lowercase(), "")

    fun apply(s: Schedule): Schedule {
        for (r in s.weekday) tweak(r, weekend = false)
        for (r in s.weekend) tweak(r, weekend = true)
        for (r in s.weekday + s.weekend) fixAbbrev(r)
        for (r in s.weekday + s.weekend) Directions.apply(r)
        return s
    }

    private fun fixAbbrev(r: Route) {
        for (st in r.stops) {
            st.name = Abbrev.fix(st.name)
            st.sub = st.sub?.let { Abbrev.fix(it) }
        }
        for (i in r.notes.indices) r.notes[i] = Official.note(Abbrev.fix(r.notes[i]))
    }

    private fun starFirst(st: Stop?, count: Int) {
        if (st == null) return
        for (i in 0 until minOf(count, st.times.size)) {
            val d = st.times[i]
            st.times[i] = Dep(d.hour, d.minute, true)
        }
    }

    private fun starTime(st: Stop, hour: Int, minute: Int) {
        for (i in st.times.indices) {
            val d = st.times[i]
            if (d.hour == hour && d.minute == minute) st.times[i] = Dep(hour, minute, true)
        }
    }

    private fun find(r: Route, name: String): Stop? =
        r.stops.firstOrNull { norm(it.name) == norm(name) }

    private fun sortTimes(st: Stop) = st.times.sortBy { it.hour * 60 + it.minute }

    private fun renameNote(r: Route, from: String, to: String) {
        for (i in r.notes.indices) if (norm(r.notes[i]) == norm(from)) r.notes[i] = to
    }

    private fun tweak(r: Route, weekend: Boolean) {
        when (r.number) {
            "3" -> {
                find(r, "пл.Победы")?.name = "пл.Победы (КБСМП)"
            }
            "7" -> {
                r.noteOnce = true
            }
            "11" -> {
                find(r, "пл. Победы")?.name = "пл. Победы (Аптека)"
            }
            "22" -> {
                val avtoz = find(r, "Автозаводская")
                val school = r.stops.firstOrNull { norm(it.name).startsWith("37") }
                if (!weekend) {
                    // ранние рейсы через промзону (только будни)
                    starFirst(school, 5)
                    starFirst(avtoz, 6)
                    r.notes.add("через промзону")
                    r.noteOnce = true
                }
                avtoz?.name = "ул. Автозаводская"
                school?.name = "8-й мкрн. Киселевка"
            }
            "24" -> {
                // в выходные маршрут называется 24в
                if (weekend) r.number = "24в"
                r.noteOnce = true
            }
            "25" -> {
                find(r, "8-й Микрорайон")?.name = "8-й мкрн. Киселевка"
            }
            "30" -> {
                find(r, "Желябова")?.name = "пл. Желябова"
                find(r, "мкр.Гнездово")?.name = "мкрн. Гнёздово (ул. Щорса)"
            }
            "9" -> {
                find(r, "пл. Победы-Садки")?.let {
                    it.name = "пл.Победы (КБСМП)"
                    it.sub = "в направлении Садки"
                }
            }
            "8" -> {
                renameNote(r, "в гараж", "до пл. Победы")
            }
            "14" -> {
                // рейса 19:25 на сайте нет, добавлен вручную (только будни)
                if (!weekend) {
                    find(r, "Шейновка")?.let {
                        starTime(it, 13, 50)
                        it.times.add(Dep(19, 25, true))
                        sortTimes(it)
                    }
                    r.notes.add("до пл. Победы")
                }
            }
            "33" -> {
                var prev = ""
                for (st in r.stops) {
                    if (norm(st.name).contains("киевская")) {
                        st.name = "ул. 2я Киевская"
                        st.sub = if (norm(prev).startsWith("жд")) {
                            "в направлении Вишенки"
                        } else {
                            "в направлении Ж/д вокзал"
                        }
                    }
                    prev = st.name
                }
            }
            "34" -> {
                // три последних рейса с Королевки (только будни)
                if (!weekend) {
                    find(r, "Королевка")?.let { st ->
                        val n = st.times.size
                        for (i in maxOf(0, n - 3) until n) {
                            val d = st.times[i]
                            st.times[i] = Dep(d.hour, d.minute, true)
                        }
                    }
                    r.notes.add("до школы №37")
                }
            }
            "50" -> {
                r.notes.clear()
                r.notes.add("до пл. Желябова")
                val subs = listOf("Велижская — Вишенки", "Желябова — Вишенки", "Вишенки — Велижская")
                if (r.stops.size == subs.size) {
                    r.stops.forEachIndexed { i, st -> st.sub = subs[i] }
                }
            }
            "53" -> {
                // блок «Вишенки»: только подпись и время, без звёздочки
                find(r, "Вишенки")?.let { st ->
                    st.sub = "в направлении пл. Желябова"
                    for (i in st.times.indices) {
                        val d = st.times[i]
                        st.times[i] = Dep(d.hour, d.minute, false)
                    }
                }
            }
            "54" -> {
                find(r, "Школа (Кр.Бор)")?.name = "Школа (Красный Бор)"
            }
        }
    }
}

/**
 * Единый вежливый стиль сносок: «* Рейс следует до пл. Победы».
 * Сноски сайта и добавленные вручную приводятся к одному виду.
 */
object Official {
    private val starts = listOf("до ", "только до", "через ", "с заездом", "без заезда", "в ")

    fun note(s: String): String {
        val t = s.trim().trimEnd('.', ';')
        val lower = t.lowercase()
        val text = when {
            lower.startsWith("рейс") -> t.replaceFirstChar { it.uppercase() }
            starts.any { lower.startsWith(it) } -> "Рейс следует " + t.replaceFirstChar { it.lowercase() }
            else -> t.replaceFirstChar { it.uppercase() }
        }
        return text.replace("продлен ", "продлён ")
    }
}

/**
 * Автобусы: расписания делятся на плитки по направлениям (заголовок плитки: конечная «куда»).
 * Названия конечных остановок не меняются, у промежуточных подпись «откуда - куда».
 * Состав плиток задан вручную по номеру маршрута и индексам блоков сайта.
 * Если на сайте блоков стало меньше, маршрут остаётся плоским списком.
 */
object Directions {
    private class Part(val index: Int, val label: String? = null)
    private class Spec(val heading: String, val parts: List<Part>)

    private fun two(toFirst: String, toSecond: String) = listOf(
        Spec(toFirst, listOf(Part(0))),
        Spec(toSecond, listOf(Part(1)))
    )

    private fun specFor(r: Route): List<Spec>? = when (r.number) {
        "3" -> two("Колодня", "пл. Победы")
        "7" -> two("Корохоткино", "пл. Победы")
        "8" -> two("М.Краснофлотская", "пл. Победы")
        "9" -> listOf(
            Spec("Колхозный переулок", listOf(Part(0), Part(1, "Садки - Колхозный переулок"), Part(2)))
        )
        "11" -> two("Рябиновая поляна", "пл. Победы")
        "12" -> listOf(
            Spec("Пронино", listOf(Part(0), Part(1, "Красный Бор - Пронино"))),
            Spec("пл. Желябова", listOf(Part(2), Part(3, "Красный Бор - пл. Желябова")))
        )
        "14" -> two("ул. Шейна", "ул. Кирова")
        "15" -> two("пос. Анастасино", "пл. Желябова")
        "19" -> two("Колодня", "пл. Победы")
        "22" -> two("8-й мкрн. Киселевка", "ул. Автозаводская")
        "24" -> listOf(
            Spec("ТЭЦ-2", listOf(Part(0))),
            Spec("пл. Победы", listOf(Part(1), Part(2)))
        )
        "24в" -> listOf(
            Spec("ТЭЦ-2", listOf(Part(1))),
            Spec("пл. Победы", listOf(Part(0), Part(2)))
        )
        "25" -> two("8-й мкрн. Киселевка", "Ж/д вокзал")
        "28" -> two("п. Дубровенка", "пл. Желябова")
        "30" -> two("мкрн. Гнёздово (ул. Щорса)", "пл. Желябова")
        "31" -> two("Миловидово", "пл. Желябова")
        "31к" -> two("ЖК Загорье", "пл. Желябова")
        "33" -> if (r.stops.size == 4) {
            listOf(
                Spec("Вишенки", listOf(Part(0), Part(1, "ул. 2я Киевская - Вишенки"))),
                Spec("Ж/д вокзал", listOf(Part(2), Part(3, "ул. 2я Киевская - Ж/д вокзал")))
            )
        } else {
            listOf(
                Spec("Вишенки", listOf(Part(0))),
                Spec("Ж/д вокзал", listOf(Part(1), Part(2, "ул. 2я Киевская - Ж/д вокзал")))
            )
        }
        "34" -> two("7-й мкрн. (Киселевка)", "мкрн. Королевка")
        "50" -> listOf(
            Spec("пос. Вишенки", listOf(Part(0), Part(1, "пл. Желябова - Вишенки"))),
            Spec("ул. Велижская", listOf(Part(2)))
        )
        "53" -> listOf(
            Spec("Окружная дорога", listOf(Part(0))),
            Spec("пл. Желябова", listOf(Part(1), Part(2, "Вишенки - пл. Желябова")))
        )
        "54" -> listOf(
            Spec(
                "пос. Торфопредприятие",
                listOf(Part(0), Part(1, "Школа (Красный Бор) - пос. Торфопредприятие"), Part(2, "пос. Торфопредприятие"))
            )
        )
        else -> null
    }

    fun apply(r: Route) {
        val specs = specFor(r) ?: return
        if (specs.any { sp -> sp.parts.any { it.index >= r.stops.size } }) return
        val original = r.stops.toList()
        // сноски со звёздочкой ставятся под тем списком, где эти звёздочки
        val single = r.notes.distinct().singleOrNull()
        val under = single != null && original.any { st -> st.times.any { it.starred } }
        val lastStarred = original.lastOrNull { st -> st.times.any { it.starred } }
        val used = mutableSetOf<Int>()
        for (sp in specs) {
            val g = Group(sp.heading)
            for (p in sp.parts) {
                val st = original[p.index]
                used.add(p.index)
                if (st.times.isEmpty()) continue
                if (p.label != null) st.name = p.label
                st.sub = null
                if (under && st.times.any { it.starred } && (!r.noteOnce || st === lastStarred)) {
                    st.footnotes.add("* $single")
                }
                g.stops.add(st)
            }
            if (g.stops.isNotEmpty()) r.groups.add(g)
        }
        // блоки, которых нет в описании (сайт добавил), не теряем
        val rest = original.filterIndexed { i, st -> i !in used && st.times.isNotEmpty() }
        if (rest.isNotEmpty()) {
            val g = Group("Другие рейсы")
            for (st in rest) {
                st.sub = null
                g.stops.add(st)
            }
            r.groups.add(g)
        }
        r.stops.clear()
        if (under) r.notes.clear()
    }
}
