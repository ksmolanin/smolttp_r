package app.muttp.schedule

/**
 * Ручные правки поверх данных сайта (подписи, сноски, добавленные рейсы).
 * Применяются после Merger, только для показа. Сайт при этом не меняется.
 * Если сайт поменяет названия остановок, правка просто не найдёт остановку и ничего не сделает.
 */
object Tweaks {
    private val nonWord = Regex("""[^\p{L}\p{N}]""")
    private fun norm(s: String) = nonWord.replace(s.lowercase(), "")

    fun apply(s: Schedule): Schedule {
        for (r in s.weekday) tweak(r, weekend = false)
        for (r in s.weekend) tweak(r, weekend = true)
        return s
    }

    private fun find(r: Route, name: String): Stop? =
        r.stops.firstOrNull { norm(it.name) == norm(name) }

    private fun sortTimes(st: Stop) = st.times.sortBy { it.hour * 60 + it.minute }

    private fun renameNote(r: Route, from: String, to: String) {
        for (i in r.notes.indices) if (norm(r.notes[i]) == norm(from)) r.notes[i] = to
    }

    private fun tweak(r: Route, weekend: Boolean) {
        when (r.number) {
            "3" -> {
                find(r, "пл.Победы")?.name = "пл.Победы (КБСМП)"
            }
            "9" -> {
                find(r, "пл. Победы-Садки")?.let {
                    it.name = "пл.Победы (КБСМП)"
                    it.sub = "в направлении Садки"
                }
            }
            "8" -> {
                renameNote(r, "в гараж", "до пл. Победы")
            }
            "12" -> {
                r.stops.firstOrNull()?.sub = "Желябова — Пронино"
            }
            "14" -> {
                // рейса 19:25 на сайте нет, добавлен вручную (только будни)
                if (!weekend) {
                    find(r, "Шейновка")?.let {
                        it.times.add(Dep(19, 25, true))
                        sortTimes(it)
                    }
                    r.notes.add("до пл. Победы")
                }
            }
            "33" -> {
                var prev = ""
                for (st in r.stops) {
                    if (norm(st.name).contains("киевская")) {
                        st.sub = if (norm(prev).startsWith("жд")) {
                            "в направлении Вишенки"
                        } else {
                            "в направлении Ж/д вокзал"
                        }
                    }
                    prev = st.name
                }
            }
            "34" -> {
                // три последних рейса с Королевки (только будни)
                if (!weekend) {
                    find(r, "Королевка")?.let { st ->
                        val n = st.times.size
                        for (i in maxOf(0, n - 3) until n) {
                            val d = st.times[i]
                            st.times[i] = Dep(d.hour, d.minute, true)
                        }
                    }
                    r.notes.add("до школы №37")
                }
            }
            "50" -> {
                r.notes.clear()
                r.notes.add("до пл. Желябова")
                val subs = listOf("Велижская — Вишенки", "Желябова — Вишенки", "Вишенки — Велижская")
                if (r.stops.size == subs.size) {
                    r.stops.forEachIndexed { i, st -> st.sub = subs[i] }
                }
            }
            "53" -> {
                find(r, "Вишенки")?.sub = "в направлении пл. Желябова"
            }
            "54" -> {
                find(r, "Школа (Кр.Бор)")?.name = "Школа (Красный Бор)"
            }
        }
    }
}
