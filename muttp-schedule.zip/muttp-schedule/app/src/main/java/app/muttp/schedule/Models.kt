package app.muttp.schedule

import java.util.Locale

/** Одно время отправления. starred = рейс со звёздочкой (смысл — в notes маршрута). */
data class Dep(val hour: Int, val minute: Int, val starred: Boolean, val mark: String = "") {
    fun label(): String =
        String.format(Locale.ROOT, "%d:%02d", hour, minute) + (if (starred) "*" else "") + mark
}

class Stop(var name: String) {
    /** Уточнение под названием остановки, например «в направлении Вишенки». */
    var sub: String? = null
    val times = mutableListOf<Dep>()

    /** Готовые строки сносок под списком времён (трамваи). */
    val footnotes = mutableListOf<String>()
}

/** Плитка направления внутри окна маршрута (троллейбусы): заголовок и списки по остановкам отправления. */
class Group(val title: String) {
    val stops = mutableListOf<Stop>()
}

class Route(var number: String, var title: String) {
    /** Если не пусто, окно маршрута показывает направления плитками, а не плоский список остановок. */
    val groups = mutableListOf<Group>()

    /** true: сноска показывается один раз (под последним списком со звёздочками), а не под каждым. */
    var noteOnce = false

    /** Подпись направлений на плитке, если задана вручную (маршрутки). */
    var lines: List<String>? = null

    /** Крупный текст в окне маршрута вместо списка времён, например «Каждые 15 минут». */
    val info = mutableListOf<String>()

    /** Обычные примечания внизу окна маршрута (без звёздочки). */
    val remarks = mutableListOf<String>()
    val stops = mutableListOf<Stop>()
    val notes = mutableListOf<String>()
}

class Schedule(val weekday: List<Route>, val weekend: List<Route>)
