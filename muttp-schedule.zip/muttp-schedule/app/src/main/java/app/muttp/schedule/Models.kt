package app.muttp.schedule

import java.util.Locale

/** Одно время отправления. starred = рейс со звёздочкой (смысл — в notes маршрута). */
data class Dep(val hour: Int, val minute: Int, val starred: Boolean) {
    fun label(): String =
        String.format(Locale.ROOT, "%d:%02d", hour, minute) + if (starred) "*" else ""
}

class Stop(var name: String) {
    /** Уточнение под названием остановки, например «в направлении Вишенки». */
    var sub: String? = null
    val times = mutableListOf<Dep>()
}

class Route(val number: String, var title: String) {
    val stops = mutableListOf<Stop>()
    val notes = mutableListOf<String>()
}

class Schedule(val weekday: List<Route>, val weekend: List<Route>)
