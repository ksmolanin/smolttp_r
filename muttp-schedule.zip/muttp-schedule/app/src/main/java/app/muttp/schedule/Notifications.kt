package app.muttp.schedule

import android.content.Context
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class Notice(
    val id: String,
    val title: String,
    val type: String,
    val text: String,
    val url: String
)

/**
 * Загружает объявления с главной страницы muttp.ru.
 * Новизна определяется по отпечатку заголовка и текста, прочтение хранится на устройстве.
 */
object NotificationsRepo {
    private const val PAGE = "https://muttp.ru/"
    private const val PREFS = "muttp_notices"
    private const val DATA = "notices"
    private const val READ = "read_ids"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): List<Notice> {
        val raw = prefs(c).getString(DATA, null) ?: return emptyList()
        return try {
            val arr = org.json.JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Notice(o.getString("id"), o.getString("title"), o.getString("type"),
                    o.getString("text"), o.getString("url"))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun unreadCount(c: Context): Int {
        val read = prefs(c).getStringSet(READ, emptySet()).orEmpty()
        return load(c).count { it.id !in read }
    }

    fun markRead(c: Context, id: String) {
        val read = prefs(c).getStringSet(READ, emptySet()).orEmpty().toMutableSet()
        read.add(id)
        prefs(c).edit().putStringSet(READ, read).apply()
    }

    fun update(c: Context): String? {
        return try {
            val conn = URL(PAGE).openConnection() as HttpURLConnection
            val html = try {
                conn.connectTimeout = 15000
                conn.readTimeout = 25000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36")
                if (conn.responseCode != 200) error("HTTP " + conn.responseCode)
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally { conn.disconnect() }

            val found = parse(html)
            if (found.isNotEmpty()) {
                val read = prefs(c).getStringSet(READ, emptySet()).orEmpty().toMutableSet()
                // Если объявление уже было сохранено, статус прочтения сохраняется.
                // Новые ID отсутствуют в read и поэтому подсвечиваются.
                val validIds = found.map { it.id }.toSet()
                read.retainAll(validIds)
                prefs(c).edit()
                    .putString(DATA, org.json.JSONArray().apply {
                        found.forEach { n -> put(org.json.JSONObject().apply {
                            put("id", n.id); put("title", n.title); put("type", n.type)
                            put("text", n.text); put("url", n.url)
                        }) }
                    }.toString())
                    .putStringSet(READ, read)
                    .putLong("checked_ms", System.currentTimeMillis())
                    .apply()
            } else if (load(c).isEmpty()) {
                return "На сайте не найдены объявления пассажирам"
            }
            null
        } catch (e: Exception) {
            e.message ?: "Не удалось загрузить объявления"
        }
    }

    private fun parse(html: String): List<Notice> {
        val doc = Jsoup.parse(html, PAGE)
        // На главной есть боковая колонка с вакансиями, субсидиями и виджетами.
        // Берём только основную область публикаций, никогда не весь document.body().
        val root = doc.selectFirst("main, #primary, .site-main, #content") ?: doc.body()
        root.select("aside, #secondary, .sidebar, .widget, nav, header, footer, script, style").remove()

        val result = LinkedHashMap<String, Notice>()
        val articles = root.select("article, .post, .news-item, .announcement")
            .filter { article -> article.parents().none { parent ->
                parent.tagName() == "aside" || parent.id() == "secondary" ||
                    parent.classNames().any { it.contains("sidebar") || it.contains("widget") }
            } }

        for (article in articles) {
            val titleEl = article.selectFirst(".entry-title, .post-title, h1, h2, h3, h4")
            val bodyEl = article.selectFirst(".entry-content, .post-content, .entry-summary, .post-body") ?: article
            val formatted = formattedText(bodyEl)
            val title = titleEl?.text()?.trim().orEmpty()
            val type = classify(title + "\n" + formatted) ?: continue
            val clean = cleanAnnouncement(formatted)
            if (clean.length < 20) continue
            val finalTitle = title.takeIf { it.isNotBlank() && classify(it) == null } ?: "Объявление"
            val link = article.selectFirst("a[href]")?.absUrl("href")
                ?.takeIf { it.startsWith("https://muttp.ru") } ?: PAGE
            val id = sha256((finalTitle + "|" + clean).lowercase())
            result[id] = Notice(id, finalTitle, type, clean, link)
        }

        // На некоторых версиях главной публикации идут не в article, а отдельными
        // блоками. Резервный разбор всё равно ограничен основной колонкой.
        if (result.isEmpty()) {
            val text = formattedText(root)
            val marker = Regex("(?i)УВАЖАЕМЫЕ\\s+ПАССАЖИРЫ!?|ВНИМАНИЕ\\s+ПАССАЖИРОВ!?")
            val matches = marker.findAll(text).toList()
            for (i in matches.indices) {
                val start = matches[i].range.first
                val end = if (i + 1 < matches.size) matches[i + 1].range.first else text.length
                val chunk = cleanAnnouncement(text.substring(start, end))
                if (chunk.length < 30) continue
                val type = classify(matches[i].value) ?: continue
                val id = sha256(chunk.lowercase())
                result[id] = Notice(id, "Объявление", type, chunk, PAGE)
            }
        }
        return result.values.toList()
    }

    /** Собирает текст с сохранением абзацев, переносов строк и пунктов списка. */
    private fun formattedText(element: Element): String {
        val out = StringBuilder()
        fun walk(node: Node) {
            when (node) {
                is TextNode -> out.append(node.wholeText)
                is Element -> {
                    val tag = node.normalName()
                    val block = tag in setOf("p", "div", "li", "br", "h1", "h2", "h3", "h4", "tr")
                    if (tag == "br") out.append('\n')
                    else {
                        if (block && out.isNotEmpty() && out.last() != '\n') out.append('\n')
                        node.childNodes().forEach(::walk)
                        if (block && out.isNotEmpty() && out.last() != '\n') out.append('\n')
                    }
                }
                else -> node.childNodes().forEach(::walk)
            }
        }
        walk(element)
        return out.toString().lines().map { it.replace(Regex("[\\t\\u00A0 ]+"), " ").trim() }
            .filter { it.isNotEmpty() }.joinToString("\n").trim()
    }

    /** Убирает служебное приветствие, которое сайт повторяет перед каждым текстом. */
    private fun cleanAnnouncement(value: String): String {
        val greeting = Regex("(?i)^\\s*(?:УВАЖАЕМЫЕ\\s+ПАССАЖИРЫ!?|ВНИМАНИЕ\\s+ПАССАЖИРОВ!?)[\\s.!,:;—-]*")
        return value.lines().dropWhile { it.isBlank() }.joinToString("\n")
            .replace(greeting, "").trim()
    }

    private fun classify(text: String): String? {
        val respectful = Regex("(?i)УВАЖАЕМЫЕ\\s+ПАССАЖИРЫ").find(text)
        val attention = Regex("(?i)ВНИМАНИЕ\\s+ПАССАЖИРОВ").find(text)
        return when {
            respectful == null && attention == null -> null
            attention == null -> "УВАЖАЕМЫЕ ПАССАЖИРЫ!"
            respectful == null -> "ВНИМАНИЕ ПАССАЖИРОВ!"
            attention.range.first < respectful.range.first -> "ВНИМАНИЕ ПАССАЖИРОВ!"
            else -> "УВАЖАЕМЫЕ ПАССАЖИРЫ!"
        }
    }

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
