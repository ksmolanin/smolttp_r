package app.muttp.schedule

/**
 * Подписи направлений для плитки: две строки (одна конечная, другая конечная).
 *
 * 1) Если номер маршрута есть в manual, берётся оттуда.
 * 2) Иначе название делится по тире из заголовка маршрута на сайте
 *    («пл.» заменяется на «площадь», кавычки убираются).
 *
 * Чтобы задать название вручную, раскомментируй пример и допиши свои маршруты.
 */
object RouteNames {
    private val manual: Map<String, List<String>> = mapOf(
        // "3" to listOf("площадь Победы", "Колодня"),
    )

    private val dash = Regex("""\s*[—–]\s*|\s+-\s+""")
    private val quotes = Regex("""[«»"]""")
    private val spaces = Regex("""\s+""")

    fun lines(r: Route): List<String> = manual[r.number] ?: auto(r.title)

    private fun auto(title: String): List<String> {
        val t = title.replace("пл. ", "площадь ").replace("пл.", "площадь ")
        val parts = t.split(dash).map { clean(it) }.filter { it.isNotEmpty() }
        return when {
            parts.isEmpty() -> emptyList()
            parts.size == 1 -> parts
            else -> listOf(parts.first(), parts.drop(1).joinToString(" – "))
        }
    }

    private fun clean(s: String): String = spaces.replace(quotes.replace(s, ""), " ").trim()
}
