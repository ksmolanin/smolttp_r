package app.muttp.schedule

/**
 * Подписи направлений для плитки: по одной строке на пункт (обычно две, у 12 три).
 * Сокращения («пл.», «ул.», «мкр.») сохраняются как на сайте.
 *
 * 1) Если номер маршрута есть в manual, берётся оттуда.
 * 2) Иначе название делится по тире из заголовка маршрута на сайте.
 *
 * manual — черновик по заголовкам с сайта. Замени на свой список, когда пришлёшь.
 */
object RouteNames {
    private val manual: Map<String, List<String>> = mapOf(
        "3" to listOf("пл. Победы", "Колодня"),
        "7" to listOf("пл. Победы", "Корохоткино"),
        "8" to listOf("пл. Победы", "М.Краснофлотская"),
        "9" to listOf("Садки", "Колхозный переулок"),
        "11" to listOf("пл. Победы", "Рябиновая поляна"),
        "12" to listOf("пл. Желябова", "Пронино", "ч/з Красный бор"),
        "14" to listOf("ул. Шейна", "ул. Кирова"),
        "15" to listOf("пос. Анастасино", "пл. Желябова"),
        "19" to listOf("Спортбаза", "пл. Победы"),
        "22" to listOf("Автозаводская", "Киселёвка"),
        "24" to listOf("пл. Победы", "ТЭЦ-2"),
        "25" to listOf("Ж/д вокзал", "8-й мкр. (Киселевка)"),
        "28" to listOf("пл. Желябова", "п. Дубровенка"),
        "30" to listOf("ул. Щорса", "пл. Желябова"),
        "31" to listOf("пл. Желябова", "Миловидово"),
        "31к" to listOf("пл. Желябова", "ЖК Загорье"),
        "33" to listOf("ДРЦ Вишенки", "Ж/д вокзал"),
        "34" to listOf("мкр. Королевка", "7-й мкр. (Киселевка)"),
        "50" to listOf("пос. Вишенки", "ул. Велижская"),
        "53" to listOf("пл. Желябова", "Окружная дорога"),
        "54" to listOf("пл. Желябова", "пос. Торфопредприятие"),
    )

    private val dash = Regex("""\s*[—–]\s*|\s+-\s+""")
    private val quotes = Regex("""[«»"]""")
    private val spaces = Regex("""\s+""")

    fun lines(r: Route): List<String> = manual[r.number] ?: auto(r.title)

    private fun auto(title: String): List<String> =
        title.split(dash).map { clean(it) }.filter { it.isNotEmpty() }

    private fun clean(s: String): String = spaces.replace(quotes.replace(s, ""), " ").trim()
}
