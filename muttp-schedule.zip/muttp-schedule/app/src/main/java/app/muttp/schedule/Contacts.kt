package app.muttp.schedule

/** Контакты внизу главного экрана. Здесь можно править адреса, телефоны и сайт. */
object Contacts {
    /** label: подпись перед номером; display: как показан номер; dial: что попадёт в набор номера. */
    class Phone(val label: String, val display: String, val dial: String)

    val addresses = listOf("ул. Шевченко 85", "Трамвайный пр. 7")

    val phones = listOf(
        Phone("МУТТП", "+7 4812 556172", "+74812556172"),
        Phone("ак1308", "+7 4812 310017", "+74812310017")
    )

    const val SITE = "muttp.ru"
}
