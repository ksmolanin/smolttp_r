# Расписание МУТТП (автобусы, город)

Раз в сутки в 05:20 по Москве (только по Wi-Fi) скачивает
https://muttp.ru/raspisanie-dvizheniya-avtobusov/, проверяет и сохраняет.
Показывает будни/выходные, маршруты, остановки и времена.

Сборка: push в main -> GitHub Actions -> Artifacts -> app-debug.apk
(или `gradle assembleDebug`, JDK 17).
